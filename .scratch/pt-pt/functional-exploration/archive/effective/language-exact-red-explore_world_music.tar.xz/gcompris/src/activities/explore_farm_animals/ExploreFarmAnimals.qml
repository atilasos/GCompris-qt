/* GCompris - ExploreFarmAnimals.qml
*
* SPDX-FileCopyrightText: 2015 Djalil MESLI <djalilmesli@gmail.com>
*
* Authors:
*   Beth Hadley <bethmhadley@gmail.com> (GTK+ version)
*   Djalil MESLI <djalilmesli@gmail.com> (Qt Quick port)
*
*   SPDX-License-Identifier: GPL-3.0-or-later
*/

import core 1.0

ExploreLevels {
    id: activity

    numberOfLevel: 1
    url: "qrc:/gcompris/src/activities/explore_farm_animals/resource/"
    hasAudioQuestions: true
    needsVoices: true
}
