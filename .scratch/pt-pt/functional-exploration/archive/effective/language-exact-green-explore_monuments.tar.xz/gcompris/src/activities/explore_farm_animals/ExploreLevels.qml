import QtTest
/* GCompris - ExploreLevels.qml
*
* SPDX-FileCopyrightText: 2015 Ayush Agrawal <ayushagrawal288@gmail.com>
*
* Authors:
*   Beth Hadley <bethmhadley@gmail.com> (GTK+ version)
*   Ayush Agrawal <ayushagrawal288@gmail.com> (Qt Quick port)
*   Djalil MESLI <djalilmesli@gmail.com> (Qt Quick port)
*   Johnny Jazeix <jazeix@gmail.com> (Qt Quick port)
*
*   SPDX-License-Identifier: GPL-3.0-or-later
*/

import QtQuick
import core 1.0

import "../../core"
import "explore-level.js" as Activity

ActivityBase {
    id: activity

    property string url
    property bool hasAudioQuestions
    property bool needsVoices: false

    onStart: focus = true
    onStop: {}

    isMusicalActivity: needsVoices

     onActivityNextLevel: {
         Activity.nextLevel()
    }

    pageComponent: Image {
        id: activityBackground
        source: "qrc:/gcompris/src/activities/chess/resource/background-wood.svg"
        width: parent.width
        height: parent.height
        sourceSize.width: width
        sourceSize.height: height

        // if audio is disabled, we display a dialog to tell users this activity requires audio anyway
        property bool audioDisabled: false

        /* In order to accept any screen ratio the play area is always a 1000x1000
         * square and is centered in a big background image that is 3000x3000
         */

        Image {
            id: bg
            source: dataset.item.backgroundImage
            sourceSize.width: width
            sourceSize.height: width
            width: 3000 * activityBackground.playRatio
            height: width
            anchors.centerIn: parent
        }

        property int playX: (activity.width - playWidth) / 2
        property int playY: (activity.height - playHeight) / 2
        property int playWidth: Math.min(activity.height - (bar.height * 2.2), activity.width)
        property int playHeight: playWidth
        property double playRatio: playWidth / 1000

        focus: true

        signal start
        signal stop
        signal voiceDone

        Component.onCompleted: {
            activity.start.connect(start)
            activity.stop.connect(stop)
        }

        // Add here the QML items you need to access in javascript
        QtObject {
            id: items

            property GCAudio audioVoices: activity.audioVoices
            property alias goodAnswerSound: goodAnswerSound
            property alias badAnswerSound: badAnswerSound
            property Item main: activity.main
            property int currentLevel: activity.currentLevel
            onCurrentLevelChanged: activity.currentLevel = currentLevel
            property int numberOfLevel: activity.numberOfLevel
            onNumberOfLevelChanged: activity.numberOfLevel = numberOfLevel
            property alias bonus: bonus
            property alias score: score
            property alias progressbar: progressbar
            property alias errorRectangle: errorRectangle
            property alias dataModel: dataModel
            property alias dataset: dataset
            property alias descriptionPanel: descriptionPanel
            property bool hasAudioQuestions: activity.hasAudioQuestions
            property var questionOrder
            property var currentQuestion: ""
            property alias okButton: okButton
            property bool bonusPlaying: false
            property bool buttonsBlocked: false
            property bool descriptionBonusDone: false
        }

        Loader {
            id: dataset
            asynchronous: false
            onStatusChanged: {
                if (status == Loader.Ready) {
                    // create table of size N filled with numbers from 0 to N
                    items.questionOrder = Array.apply(null, {length: items.dataModel.count}).map(Number.call, Number)
                }
            }
        }

        onStart: {
            activity.audioVoices.done.connect(voiceDone)
            Activity.start(items, url)
            if(activity.needsVoices === true) {
                if(!ApplicationSettings.isAudioVoicesEnabled || !ApplicationSettings.isAudioEffectsEnabled)
                    activityBackground.audioDisabled = true
            }
        }
        onStop: { Activity.stop() }

        Keys.onEscapePressed: {
            descriptionPanel.visible ? descriptionPanel.closeDescriptionPanel() : home()
        }

        onVoiceDone: {
            if(items.bonusPlaying) {
                items.bonusPlaying = false;
                Activity.repeat();
            }
        }

        GCSoundEffect {
            id: goodAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/completetask.wav"
        }

        GCSoundEffect {
            id: badAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/crash.wav"
        }

        GCTextPanel {
            id: instructionPanel
            panelWidth: parent.width - 3 * GCStyle.baseMargins - score.width
            panelHeight: 50 * ApplicationInfo.ratio
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.horizontalCenterOffset: (-score.width - GCStyle.baseMargins) * 0.5
            anchors.top: parent.top
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: (dataset.item && items.score.currentSubLevel - 1 != items.score.numberOfSubLevels  && items.score.currentSubLevel != 0) ? dataset.item.instructions[items.score.currentSubLevel - 1].text : ""
            color: GCStyle.lightBg
            border.color: GCStyle.blueBorder
            border.width: GCStyle.thinBorder
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
        }

        GCTextPanel {
            id: questionPanel
            panelWidth: instructionPanel.panelWidth
            panelHeight: instructionPanel.panelHeight
            anchors.horizontalCenter: instructionPanel.horizontalCenter
            anchors.top: instructionPanel.bottom
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: items.currentQuestion ? items.currentQuestion.text2 : ""
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
            color: GCStyle.lighterBg
            border.color: GCStyle.lightGrayBorder
            visible: items.score.currentSubLevel == 3 || (items.score.currentSubLevel == 2 && !items.hasAudioQuestions)

        }

        Score {
            id: score
            z: 1
            isScoreCounter: false
            anchors {
                bottom: undefined
                right: parent.right
                top: parent.top
                margins: GCStyle.baseMargins
            }
        }

        BarButton {
            id: repeatItem
            source: "qrc:/gcompris/src/core/resource/bar_repeat.svg";
            width: Math.min(GCStyle.bigButtonHeight, score.width)
            anchors.top: score.bottom
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            visible: items.score.currentSubLevel == 2 && activity.hasAudioQuestions //&& ApplicationSettings.isAudioVoicesEnabled
            onClicked: {
                if(!items.audioVoices.isPlaying()) {
                    Activity.repeat();
                }
            }
        }

        Repeater {
            id: dataModel
            model: dataset && dataset.item && dataset.item.tab ? dataset.item.tab.length : 0
            AnimalLevels {
                questionId: index
                source: dataset.item.tab[index].image
                x: Math.round(activityBackground.playX + activityBackground.playWidth * dataset.item.tab[index].x - width / 2)
                y: Math.round(activityBackground.playY + activityBackground.playHeight * dataset.item.tab[index].y - height / 2)
                width: Math.round(activityBackground.playWidth * dataset.item.tab[index].width)
                height: Math.round(activityBackground.playHeight * dataset.item.tab[index].height)
                title: dataset.item.tab[index].title
                description: dataset.item.tab[index].text
                imageSource: dataset.item.tab[index].image2
                question: dataset.item.tab[index].text2
                audio: dataset.item.tab[index].audio !== undefined ? dataset.item.tab[index].audio : ""
                Component.onCompleted: {
                    displayDescription.connect(displayDescriptionItem)
                }
            }
        }

        function displayDescriptionItem(animal) {
            descriptionPanel.title = animal.title
            descriptionPanel.description = animal.description
            descriptionPanel.imageSource = animal.imageSource
            descriptionPanel.visible = true
            descriptionPanel.showDescriptionPanel()
        }

        AnimalDescriptionLevels {
            id: descriptionPanel
            width: activityBackground.width
            height: activityBackground.height - bar.height * 1.2
            z: instructionPanel.z + 1
        }

        Score {
            id: progressbar
            visible: items.score.currentSubLevel != 1
            anchors.bottom: bar.top
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            onStop: Activity.nextSubSubLevel();
        }

        Image {
            id: okButton
            visible: false
            source:"qrc:/gcompris/src/core/resource/bar_ok.svg"
            sourceSize.width: GCStyle.bigButtonHeight
            fillMode: Image.PreserveAspectFit
            anchors.right: parent.right
            anchors.bottom: progressbar.top
            anchors.margins: GCStyle.baseMargins
            MouseArea {
                anchors.fill: parent
                onClicked: Activity.nextLevel()
            }
        }

        ErrorRectangle {
            id: errorRectangle
            width: 0
            height: 0
            imageSize: GCStyle.smallButtonHeight
            function releaseControls() {
                items.buttonsBlocked = false;
            }
        }


        DialogHelp {
            id: dialogHelp
            onClose: home()
        }

        Bar {
            id: bar
            level: items.currentLevel + 1
            content: BarEnumContent { value: help | home | level | reload }
            onHelpClicked: {
                displayDialog(dialogHelp)
            }
            onPreviousLevelClicked: Activity.previousLevel()
            onNextLevelClicked: Activity.nextLevel()
            onHomeClicked: activity.home()
            onReloadClicked: Activity.initLevel()
        }
        Bonus {
            id: bonus
            onWin: {
                if(progressbar.visible)
                    Activity.nextLevel();
                else {
                    okButton.visible = true;
                    items.buttonsBlocked = false;
                }
            }
        }

        Loader {
            id: audioNeededDialog
            sourceComponent: GCDialog {
                parent: activity
                isDestructible: false
                message: qsTr("This activity requires sound, so it will play some sounds even if the audio voices or effects are disabled in the main configuration.")
                button1Text: qsTr("Quit")
                button2Text: qsTr("Continue")
                onButton1Hit: activity.home();
                onClose: {
                    activityBackground.audioDisabled = false;
                }
            }
            anchors.fill: parent
            focus: true
            active: activityBackground.audioDisabled
            onStatusChanged: if (status == Loader.Ready) item.start()
        }
// SPDX-License-Identifier: GPL-3.0-or-later
TestCase {
 name: 'VisibleExplorationPresentations'
 when: activity.visible
 property var expectedTexts: {"qrc:/gcompris/src/activities/explore_farm_animals/resource/animals/horse.webp": {"title": "Cavalo", "description": "O cavalo relincha. Os cavalos estão adaptados à corrida, o que lhes permite fugir rapidamente dos predadores. Têm um excelente sentido de equilíbrio e cascos com um único dedo em cada pata."}, "qrc:/gcompris/src/activities/explore_farm_animals/resource/animals/cow.webp": {"title": "Vaca", "description": "A vaca faz 'mú'. As vacas têm um amplo campo de visão, de 330°. Têm o paladar bem desenvolvido, com cerca de 20 000 papilas gustativas. Conseguem detetar odores a 8 km de distância."}, "qrc:/gcompris/src/activities/explore_farm_animals/resource/animals/owl.webp": {"title": "Coruja", "description": "A coruja faz 'hu, hu'. As corujas são animais noturnos, pelo que têm uma visão e audição excelentes à noite."}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/hedgehog.webp": {"title": "Ouriço", "description": "Os ouriços comem pequenos animais, como os sapos e os insetos, pelo que muitas pessoas os usam como animais de estimação úteis. Em caso de perigo, enrolam-se como uma bola e espetam os seus espinhos afiados."}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/narwhal.webp": {"title": "Narval", "description": "Os narvais são baleias que vivem no oceano Ártico e têm uma longa presa. Esta presa faz lembrar o corno do mítico unicórnio."}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/moose.webp": {"title": "Alce", "description": "O alce é o maior dos veados e come até 25 kg por dia. Por vezes, ergue-se sobre as patas traseiras para alcançar ramos a uma altura de até 4 metros!"}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/crocodile.webp": {"title": "Crocodilo", "description": "Um crocodilo é um enorme réptil anfíbio. Vive principalmente nos grandes rios tropicais, onde atua como predador por emboscada."}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/dragon.webp": {"title": "Dragão-de-komodo", "description": "O dragão-de-komodo é o maior lagarto vivo (até 3 metros). Habita nas ilhas da Indonésia."}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/lemur.webp": {"title": "Lémure-de-cauda-anelada", "description": "O lémure-de-cauda-anelada é um primata que vive nas regiões secas do Sudoeste de Madagáscar. A cauda às riscas torna-o fácil de ser reconhecido."}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/panda.webp": {"title": "Panda", "description": "O Panda é um urso com pelo preto e branco que vive em algumas regiões montanhosas da China central. Os pandas comem principalmente bambu."}, "qrc:/gcompris/src/activities/explore_world_music/resource/music/australia.webp": {"title": "Austrália", "description": "Os aborígenes foram os primeiros habitantes da Austrália. Cantam e tocam instrumentos como o didgeridoo, feito a partir de um tronco e que pode atingir cinco metros de comprimento."}, "qrc:/gcompris/src/activities/explore_world_music/resource/music/africa.webp": {"title": "África", "description": "A música faz parte do dia a dia de todos os povos em África. A música africana oferece uma grande variedade de tambores, sendo que acreditam que é um instrumento sagrado e mágico."}, "qrc:/gcompris/src/activities/explore_world_music/resource/music/middleeast.webp": {"title": "Médio Oriente", "description": "A música é uma parte muito importante na cultura do Médio Oriente. Algumas músicas são tocadas para chamar os fiéis às orações. O alaúde é um instrumento inventado há milhares de anos e que continua ainda a ser usado hoje em dia."}, "qrc:/gcompris/src/activities/explore_world_music/resource/music/japan.webp": {"title": "Japão", "description": "A percussão com o Taikô vem do Japão. Esse tipo de percussão era usado originalmente para assustar os inimigos nas batalhas. O seu som é bastante alto e os espetáculos são muito excitantes com a multidão a bater palmas e os artistas aos gritos!"}, "qrc:/gcompris/src/activities/explore_world_music/resource/music/italy.webp": {"title": "Itália", "description": "A Itália é conhecida pela sua ópera. A ópera é um teatro musical onde os atores contam uma história, interpretam papéis e cantam. Os cantores de ópera, homens ou mulheres, aprendem técnicas especiais para cantarem em óperas."}, "qrc:/gcompris/src/activities/explore_world_music/resource/music/orchestra.webp": {"title": "Música clássica europeia", "description": "A Europa é a casa da música clássica. Os compositores famosos, como Bach, Beethoven e Mozart, mudaram para sempre a história da música."}, "qrc:/gcompris/src/activities/explore_monuments/resource/wonders/colosseum.webp": {"title": "Coliseu", "description": "O Coliseu é um dos edifícios mais reconhecidos da Roma clássica. Mesmo 2 000 anos após a sua construção, e apesar dos séculos em que foi abandonado e pilhado para obter materiais de construção, continua a ser imediatamente reconhecível. É um modelo clássico dos estádios atuais. Foi o primeiro anfiteatro permanente de Roma e a arena mais impressionante que o mundo clássico conhecera até então."}, "qrc:/gcompris/src/activities/explore_monuments/resource/wonders/greatWallofChina.webp": {"title": "A Grande Muralha da China", "description": "A Grande Muralha foi inscrita como Património Mundial da Humanidade pela UNESCO em 1987. Tal como um dragão gigante, ela sobe e desce por vários desertos, prados, montanhas e planícies, estendendo-se por cerca de 13 170 milhas (21 196 quilómetros) de Este para Oeste na China."}, "qrc:/gcompris/src/activities/explore_monuments/resource/india/hawaMahal.webp": {"title": "Hawa Mahal", "description": "O Hawa Mahal é um palácio em Jaipur, na Índia, cujo nome se refere a uma fachada alta que permitia às mulheres da família real observar os festivais na rua sem serem vistas do exterior. Construído em arenito vermelho e rosa, situa-se junto ao Palácio da Cidade e estende-se até à zenana, os aposentos das mulheres."}, "qrc:/gcompris/src/activities/explore_monuments/resource/india/konarkSunTemple.webp": {"title": "Templo do Sol de Konark", "description": "O Templo do Sol de Konark (também dito como Konarak) é um templo Hindu do século XIII dedicado ao deus do Sol. Com o formato de uma carroça gigante, o templo é conhecido pelas esculturas em pedra formidáveis que cobrem toda a estrutura."}, "qrc:/gcompris/src/activities/explore_monuments/resource/india/mysorePalace.webp": {"title": "Palácio de Mysore", "description": "O Palácio de Mysore ou o Palácio do Marajá Mysore é um dos maiores e mais espetaculares monumentos do país. Também conhecido como Amba Vilas, localiza-se no coração da cidade de Mysore. O palácio foi inicialmente construído pelos reis Wodeyar no século XIV."}, "qrc:/gcompris/src/activities/explore_monuments/resource/india/victoriaMemorial.webp": {"title": "Memorial de Vitória", "description": "O Memorial de Vitória foi construído para comemorar o pico do Império Britânico na Índia. O Memorial de Vitória, concebido pelo Lorde Curzon, representa o clímax arquitetónico da cidade de Kolkata (Calcutá), e mistura o melhor da arquitetura Britânica e a Mughal. O pavilhão do Memorial de Vitória foi construído com mármore branco de Makrana."}, "qrc:/gcompris/src/activities/explore_monuments/resource/france/montStMichel.webp": {"title": "Monte Saint-Michel", "description": "O Monte Saint-Michel é uma ilha rochosa na Normandia, perto da foz do rio Couesnon. É conhecido pela sua abadia e pelas grandes marés da baía. Existe uma ponte de acesso pedonal durante todo o ano; nas marés mais altas, a entrada pode ficar temporariamente coberta pela água."}, "qrc:/gcompris/src/activities/explore_monuments/resource/france/reimsCathedral.webp": {"title": "Catedral de Reims", "description": "Pelo tamanho, a Catedral de Reims é uma construção bastante extraordinária: desenhada para acomodar multidões enormes, as suas dimensões gigantes incluem uma área de superfície de 6 650 m2 e um comprimento de 122m. Uma obra-prima da arte Gótica e o local de coroação dos Reis de França, foi inscrita como Património Mundial da Humanidade pela UNESCO em 1991. A Meca dos turistas na região de Champagne dá as boas-vindas a 1 500 000 de visitantes por ano."}, "qrc:/gcompris/src/activities/explore_monuments/resource/france/pontduGard.webp": {"title": "Pont du Gard", "description": "O Pont du Gard foi construído no século I d. C. para permitir que o aqueduto de Nîmes, com quase 50 km de comprimento, atravessasse o rio Gardon. Os arquitetos e engenheiros hidráulicos romanos conceberam uma ponte com três níveis e quase 50 m de altura, cujo nível mais longo mede 275 m. Criaram uma obra-prima técnica e artística."}, "qrc:/gcompris/src/activities/explore_monuments/resource/france/chateaudeChambord.webp": {"title": "Castelo de Chambord", "description": "Prestigiante, majestoso, colossal, extravagante - são estes adjetivos suficientes para descrever por completo o esplendor de Chambord? O maior castelo do Vale do Loire é de facto cheio de surpresas para os que forem suficientemente sortudos para explorar o seu domínio. Esta peça espetacular de arquitetura é certamente mais que um castelo: é o sonho de um Rei transformado em realidade."}, "qrc:/gcompris/src/activities/explore_monuments/resource/france/chateaudeChenonceau.webp": {"title": "Castelo de Chenonceau", "description": "O Castelo de Chenonceau é um dos castelos do vale do Loire com grande importância arquitetónica e histórica, atraindo milhares de turistas de todo o mundo. É conhecido como o Castelo das Damas devido às mulheres que influenciaram a sua construção e desenvolvimento ao longo dos séculos."}, "qrc:/gcompris/src/activities/explore_monuments/resource/france/eiffelTower.webp": {"title": "Torre Eiffel", "description": "A mundialmente famosa torre metálica foi construída para a Exposição Internacional de Paris em 1889, pelo centenário da Revolução Francesa. Na altura da sua inauguração, era o monumento mais alto do mundo."}, "qrc:/gcompris/src/activities/explore_monuments/resource/germany/brandenburgGate.webp": {"title": "Porta de Brandeburgo", "description": "A Porta de Brandeburgo é o único portão sobrevivente da cidade de Berlim e representa a reunificação da Berlim Ocidental e Oriental. Construída no século XVIII, a porta de Brandeburgo é a entrada da Unter den Linden, a avenida proeminente com árvores de tílias que conduziam em tempos diretamente ao palácio dos monarcas Prussianos. É apontada como sendo um dos marcos locais mais famosos da Europa."}, "qrc:/gcompris/src/activities/explore_monuments/resource/germany/schwerinPalace.webp": {"title": "Palácio de Schwerin", "description": "Esta fortaleza romântica dos contos de fadas, com todas as suas torres, alas e miradouros, reflete-se nas águas do Lago Schwerin. Foi terminada em 1857 e simboliza a dinastia poderosa do seu fundador, Friedrich Franz II."}, "qrc:/gcompris/src/activities/explore_monuments/resource/germany/aulaPalatina.webp": {"title": "Aula Palatina", "description": "A estrutura de tijolo, comprida e de teto alto, foi a sala do trono do imperador romano, até à destruição da cidade por tribos germânicas. Os invasores construíram uma fortaleza nas ruínas sem telhado. No século XII, o espaço foi convertido numa torre para alojar o arcebispo de Trier."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/canyondeChelly.webp": {"title": "Escarpas de Chelly", "description": "As estóicas ruínas vermelhas das Escarpas de Chelly, a Nordeste do Arizona, fazem parte por um lado do Serviço de Parques Nacionais e por outro da Nação Navajo, sendo estabelecidos como monumentos nacionais em 1931. Um conjunto de locais importantes dos antigos Nativos Americanos são preservados nos cerca de 34 000 hectares do parque, sendo que as Escarpas de Chelly também oferecem um conjunto de formações geológicas da zona Sudoeste, incluindo a Spider Rock (Rochedo da Aranha), uma espira de granito com cerca de 200 metros de altura que se eleva de forma estranha a partir do fundo da escarpa."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/georgeWashingtonBirthplace.webp": {"title": "Local de Nascimento de George Washington", "description": "O Monumento Nacional de Nascimento de George Washington existe no Condado de Westmoreland, em Virgínia, nos Estados Unidos. Originalmente iniciado por John Washington, o bisavô de George Washington, George Washington nasceu aqui em 22 de fevereiro de 1732. Ele viveu lá até aos três anos, regressando mais tarde como adolescente."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/lincolnMemorial.webp": {"title": "Memorial de Lincoln", "description": "Construída em pedra branca com 36 colunas imponentes, o Memorial de Lincoln é uma das estruturas mais reconhecidas nos Estados Unidos. O memorial fica no extremo ocidental do National Mall, no Parque de Potomac Ocidental, sendo um exemplo da arquitetura Neoclássica. Oferece uma estátua solitária de 6 metros de altura de Abraham Lincoln sentado em contemplação, a qual está rodeada por câmaras laterais de ambos os lados com as inscrições do Segundo Discurso Inaugural de Lincoln e, sem dúvida o seu mais famoso discurso, o Discurso de Gettysburg."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/mountRushmore.webp": {"title": "Monte Rushmore", "description": "O Monte Rushmore existe como altar da democracia, sendo um monumento e memorial a George Washington pelo nascimento, crescimento e ideais deste país. O Monte Rushmore simboliza a grandeza desta nação através da grandeza dos seus líderes. A escultura épica do Monte Rushmore contém as faces de quatro presidentes americanos importantes que simbolizam a rica história desta nação, uma enorme determinação e de feitos duradouros."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/navajo.webp": {"title": "Navajo", "description": "O Monumento Nacional Navajo é um Monumento Nacional localizado dentro da parte Noroeste do território da Nação Navajo, a Norte do Arizona, que foi estabelecido para preservar três baixos-relevos em penhasco do Povo Ancestral Puebloan: Keet Seel (Kitsʼiil), Betatakin (Bitátʼahkin), e a Casa da Inscrição(Tsʼah Biiʼ Kin). O monumento eleva-se no planalto de Shonto, tendo uma visão geral sobre o sistema montanhoso de Tsegi, a oeste de Kayenta, Arizona. Oferece um centro aos visitantes com um museu, dois trajetos curtos às mesetas, dois parques de campismo e uma área de piqueniques. Alguns guardas guiam os visitantes em viagens gratuitas aos relevos de Keet Seel e Betatakin. O local da Casa da Inscrição, mais a oeste, está neste momento encerrado ao público."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/statueofLiberty.webp": {"title": "Estátua da Liberdade", "description": "Talvez o monumento mais conhecido e um símbolo dos Estados Unidos seja a Estátua da Liberdade, que se situa na sua pequena ilha na Cidade de Nova Iorque. A estátua foi uma prenda do povo de França e foi inaugurada em outubro de 1886."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/fortSumter.webp": {"title": "Forte Sumter", "description": "O Forte Sumter foi originalmente construído como uma estrutura defensiva depois da guerra de 1812. Situa-se à entrada do porto de Charleston, na Carolina do Sul. As suas exposições apresentam diferentes perspetivas sobre a história dos Estados Unidos, em particular as divisões entre o Norte e o Sul que acabaram por dar origem à Guerra Civil."}, "qrc:/gcompris/src/activities/explore_monuments/resource/egypt/greatPyramidOfGiza.webp": {"title": "Grande Pirâmide de Gizé", "description": "A Grande Pirâmide de Gizé, também chamada Pirâmide de Quéops ou Khufu, é o túmulo do faraó Khufu, no Egito. É a única das Sete Maravilhas do Mundo Antigo que chegou até nós. A sua altura original era de cerca de 146,5 metros e a construção terá demorado entre 10 e 20 anos. Foi construída principalmente com pedra calcária."}, "qrc:/gcompris/src/activities/explore_monuments/resource/egypt/bentPyramid.webp": {"title": "Pirâmide Curvada", "description": "A Pirâmide Dobrada, localizada em Dahshur, foi a segunda pirâmide construída pelo faraó Sneferu. Misteriosamente, esta pirâmide real eleva-se a partir do deserto com um ângulo de 55 graus e de repente muda para um ângulo mais gradual de 43 graus. Uma teoria é de que, devido à inclinação do ângulo original, o peso a ser adicionado acima das câmaras interiores e passagens tornou-se demasiado elevado, obrigando os construtores a adotar um ângulo mais suave. Hoje em dia, a Pirâmide Curvada é a única pirâmide no Egito em que a cobertura exterior em pedra calcária polida ainda está intacta na sua maioria."}, "qrc:/gcompris/src/activities/explore_monuments/resource/egypt/meidumPyramid.webp": {"title": "Pirâmide de Meidum", "description": "Cinco milhas a Sul de Saqqara no Egito, eleva-se a misteriosa pirâmide em torre de Meidum, que nos dias de hoje pouco se parece com uma pirâmide de todo. A pirâmide foi provavelmente construída durante o reinado do faraó da 4a Dinastia Sneferu, ainda que se acredita que parte da pirâmide tenha sido iniciada pelo antecessor de Sneferu, Huni. A determinada altura da sua construção, os degraus da pirâmide foram preenchidos com uma cobertura em pedra calcária, marcando a primeira tentativa dos antigos Egípcios na construção de uma verdadeira pirâmide."}, "qrc:/gcompris/src/activities/explore_monuments/resource/egypt/redPyramid.webp": {"title": "Pirâmide Vermelha", "description": "A Pirâmide Vermelha foi uma das melhores e bem-sucedidas tentativas do faraó Sneferu na construção da primeira pirâmide de faces suaves do mundo no período do Antigo Egito. A altura da pirâmide é de 104 metros, tornando-se a 4a pirâmide mais alta do mundo no Egito. A pirâmide foi construída com rochas de pedra calcária vermelha, daí o seu nome. As pessoas locais do Egito chamavam-lhe 'el-heram el-watwaat', que significa Pirâmide-Morcego."}, "qrc:/gcompris/src/activities/explore_monuments/resource/china/forbiddenCity.webp": {"title": "Cidade Proibida", "description": "A Cidade Proibida, localizada no coração de Beijing (Pequim), na China, é um magnífico complexo do Palácio imperial que serviu de casa aos imperadores chineses e de centro político da nação por quase 500 anos, da Dinastia Ming (1368-1644) até ao fim da dinastia Qing (1644-1912). Construído entre 1406 e 1420, esta obra-prima arquitetónica abrange 180 hectares e apresenta mais de 980 edifícios preservados com 8.700 divisões, representativas do design palaciano chinês tradicional. Rodeado por um fosso e muralhas altas, a Cidade Proibida já foi inacessível ao público em geral, simbolizando a exclusividade do poder imperial."}, "qrc:/gcompris/src/activities/explore_monuments/resource/china/leshanGiantBuddha.webp": {"title": "Buda gigante de Leshan", "description": "O Buda Gigante de Leshan, localizado na província de Sichuan, na China, é uma estátua colossal esculpida num penhasco na confluência dos rios Min, Dadu e Qingyi. Com 71 metros (233 pés) de altura, é a estátua mais alta da antiguidade e é considerado Património Mundial da Humanidade pela UNESCO. Construído durante a Dinastia Tang (713-803 DC), a estátua representa Maitreya, o Buda do futuro, e foi erigido para acalmar as águas turbulentas que constituem uma ameaça ao tráfego local de embarcações. Engenhosamente projetada, a estátua inclui um sistema de drenagem oculto para evitar a erosão. A sua expressão serena e a mestria da sua execução fazem dela um símbolo de realização espiritual e artística."}, "qrc:/gcompris/src/activities/explore_monuments/resource/china/terracottaArmy.webp": {"title": "Exército de Terracota", "description": "O exército de terracota é uma coleção de milhares de soldados, cavalos e carruagens de argila em tamanho natural enterrados com o primeiro imperador da China, Qin Shi Huang, para o acompanharem na vida após a morte. Descoberto em 1974 perto de Xi'an, as figuras datam aproximadamente de 210 AC e são admiradas pelos seus incríveis detalhes, com cada guerreiro criado propositadamente para dar testemunho das diversas patentes e papéis num antigo exército chinês."}, "qrc:/gcompris/src/activities/explore_monuments/resource/china/sunAndMoonPagodas.webp": {"title": "Pagodes do Sol e da Lua", "description": "Os Pagodes do Sol e da Lua, localizados em Guilin, na China, são icónicas Torres Gémeas que simbolizam o património cultural e espiritual da cidade. Erigidos originalmente durante a Dinastia Tang, foram reconstruídos no século XX como marcos notórios no Lago Shanhu. O Pagode do Sol, com 41 metros de altura, é uma estrutura de bronze—a mais alta deste tipo no mundo—enquanto que o Pagode da Lua, com 35 metros, é construído de azulejos. Esses pagodes representam a harmonia do Yin e do Yang e estão ligados por um túnel de vidro subaquático. Iluminados à noite, são atrações populares que dão mostra da arquitetura chinesa e da engenharia moderna."}, "qrc:/gcompris/src/activities/explore_monuments/resource/china/diaolouTowers.webp": {"title": "Torres Diaolou", "description": "As torres Diaolou, que se encontram em Kaiping, Província de Guangdong, na China, são estruturas fortificadas de vários andares construídas no final do séc. XIX e inícios do séc. XX como proteção contra bandidos e inundações. Misturando estilos arquitetónicos Ocidentais como o românico e o barroco com elementos tradicionais chineses, refletem a riqueza e o poder dos emigrantes ultramarinos chineses. Construídas em betão armado reforçado, estas torres simbolizam um período de transição cultural e económica na China rural. Designadas como Património Mundial da Humanidade pela UNESCO em 2007, permanecem entre 1.800 e 3.000 originais destas torres, oferecendo uma visão única desta herança arquitetónica."}, "qrc:/gcompris/src/activities/explore_monuments/resource/italy/pantheon.webp": {"title": "Panteão", "description": "O Panteão em Roma, Itália, é um templo icónico da antiguidade construído por volta de 126 DC durante o reinado do Imperador Adriano, no local de estruturas anteriores encomendadas por Marcus Agripa. Reconhecido pelo seu brilhantismo arquitetónico, possui um enorme teto abobadado com um óculo central, simbolizando os céus, permitindo que a luz natural ilumine o interior. Originalmente dedicado a todos os deuses romanos, foi posteriormente convertido numa igreja cristã, conhecida como a Basílica de Santa Maria e dos Mártires (Santa Maria ad Martyres), em 609 DC. A sua cúpula, a maior cúpula de betão não armado do mundo, apresenta uma engenharia e simetria notáveis que durante séculos inspiraram arquitetos. As proporções harmoniosas e o significado histórico do Panteão fazem dela uma obra-prima intemporal da arquitetura clássica."}, "qrc:/gcompris/src/activities/explore_monuments/resource/italy/duomoDiMilano.webp": {"title": "Catedral de Milão", "description": "O Duomo di Milano, também conhecida como Catedral de Milão, é uma obra-prima gótica icónica localizada no coração de Milão, Itália. Construída ao longo de quase seis séculos, é uma das maiores catedrais do mundo e um símbolo do património artístico e cultural de Milão. Sua intrincada fachada está adornada com inúmeras estátuas, pináculos e gárgulas, refletindo a grandiosidade da arte gótica. Os visitantes podem explorar os seus impressionantes interiores, com belos vitrais e intrincados detalhes em mármore, ou subir até ao telhado e desfrutar de vistas deslumbrantes da cidade e dos Alpes. O Duomo permanece como um testemunho da rica história e do brilhantismo arquitetónico da Itália."}, "qrc:/gcompris/src/activities/explore_monuments/resource/italy/florenceCathedral.webp": {"title": "Catedral de Florença", "description": "A Catedral de Florença, oficialmente conhecida como Cattedrale di Santa Maria del Fiore, é uma obra-prima de renome da arquitetura gótica e renascentista localizada em Florença, Itália. Concluída em 1436, é famosa pela sua enorme cúpula de azulejos vermelhos projetada por Filippo Brunelleschi, permanecendo uma maravilha da engenharia e um símbolo da cidade. A intricada fachada em mármore da catedral, acrescentada no século XIX, complementa os tesouros artísticos do seu interior ricamente decorado. Juntamente com o Campanário de Giotto e o Batistério de São João, faz parte do Património Mundial da Humanidade da UNESCO, e as suas características históricas, culturais e a sua importância arquitetónica atraem anualmente milhões de visitantes."}, "qrc:/gcompris/src/activities/explore_monuments/resource/italy/leaningTowerOfPisa.webp": {"title": "Torre inclinada de Pisa", "description": "A Torre Inclinada de Pisa, localizada na cidade italiana de Pisa, é uma maravilha arquitetónica de renome mundial. Construída para ser torre sineira independente para a Catedral da cidade, é famosa pela sua inclinação não intencional, causada pela fundação em solo instável. Iniciada em 1173, a construção da torre estendeu-se por quase 200 anos, durante os quais foram envidados esforços para estabilizar a sua inclinação. Erguendo-se até cerca de 56 metros (183 pés), o estilo românico da torre apresenta oito andares, incluindo uma câmara sineira, adornados com colunas e arcos intrincadamente esculpidos. Reconhecida como Património Mundial da Humanidade pela UNESCO, permanece um símbolo de resiliência e de engenho."}, "qrc:/gcompris/src/activities/explore_monuments/resource/italy/pompeii.webp": {"title": "Pompeia", "description": "Pompeia foi uma antiga cidade Romana localizada perto da Nápoles dos dias de hoje, em Itália, notoriamente preservada após ter sido soterrada pela erupção do Monte Vesúvio em 79 d. C. A erupção desencadeou uma combinação mortal de cinzas, pedra-pomes e fluxos piroclásticos, que engoliram a cidade e os seus habitantes, preservando edifícios, artefactos e até mesmo restos humanos de forma incrivelmente detalhada. As escavações de Pompeia forneceram informações valiosas sobre a vida, a arquitetura e a sociedade romanas, revelando uma cidade de ruas bem planeadas, casas, banhos públicos e templos. O local é agora considerado Património Mundial da Humanidade pela UNESCO e continua a ser uma das mais importantes descobertas arqueológicas da história."}, "qrc:/gcompris/src/activities/explore_monuments/resource/japan/himejiCastle.webp": {"title": "Castelo Himeji", "description": "Himeji-jo é o exemplo mais admirável da arquitetura defensiva japonesa do séc. XVII que chegou até nós, compreendendo 83 edifícios com sistemas de defesa altamente desenvolvidos e engenhosos dispositivos protetivos que datam do início do Período Shogun. É uma obra-prima de construção em madeira, combinando a função com estética apelativa, tanto na sua aparência elegante unificada pelo gesso branco do reboco das paredes como na subtileza das relações entre as massas do edifício e as múltiplas camadas do telhado."}, "qrc:/gcompris/src/activities/explore_monuments/resource/japan/hiroshimaPeaceMemorialPark.webp": {"title": "Parque Memorial da Paz em Hiroshima", "description": "O Parque Memorial da Paz de Hiroshima é um símbolo de paz e um lembrete das consequências devastadoras da guerra. Localizado em Hiroshima, no Japão, o parque homenageia as vítimas do bombardeamento com bomba atómica a 6 de agosto de 1945. O parque apresenta vários monumentos, incluindo a icónica Abóboda da Bomba Atómica, que foi outrora um edifício governamental e agora é considerado Património Mundial da Humanidade pela UNESCO. O parque também abriga o Museu Memorial da Paz de Hiroshima, que educa os visitantes sobre os acontecimentos em torno do bombardeamento e promove uma mensagem de paz, de não-violência e da importância do desarmamento nuclear. Serve como um espaço solene de reflexão, homenageando as vidas perdidas e advogando a paz mundial."}, "qrc:/gcompris/src/activities/explore_monuments/resource/japan/arakuraShrine.webp": {"title": "Santuário Arakura Fuji Sengen", "description": "O santuário foi fundado em 705 para consagrar a divindade do local. Seguindo a grande erupção do Monte Fuji em 807, o imperador designou um enviado imperial a este santuário para realizar um ritual para deter a erupção. Conta-se que durante o Período dos Reinos Combatentes, quando Takeda Nobutora, pai de um famoso senhor da guerra Takeda Shingen, lutou contra a família Hojo, montou acampamento aqui, orou pela vitória e venceu a batalha. Ele então dedicou a sua espada a este santuário. Hoje, moradores locais e vindos de longe visitam o santuário para afastarem o mal, para orarem pela felicidade da família e pedirem um parto seguro. Na primavera, grandes multidões reúnem-se junto às cerejeiras em flor para apreciarem a vista deslumbrante do Monte Fuji."}, "qrc:/gcompris/src/activities/explore_monuments/resource/japan/okinawaShuriCastle.webp": {"title": "Castelo de Shuri, Okinawa", "description": "O Castelo Shuri, localizado em Naha, Okinawa, Japão, é considerado Património Mundial da Humanidade pela UNESCO e um símbolo da rica história cultural do Reino Ryukyu. Originalmente construído no século XIV, o castelo serviu como centro político, económico e cultural do reino durante séculos. Famoso pela sua peculiar fusão de estilos arquitetónicos chineses e japoneses, o castelo Shuri apresenta estruturas laqueadas a vermelho, decorações ornamentadas e assume uma posição dominante no topo da colina. Apesar de ter sido destruído durante a Segunda Guerra Mundial, foi meticulosamente reconstruído e tornou-se numa importante atração turística. Tragicamente, grande parte do castelo foi perdida num incêndio em 2019, mas estão em curso esforços para restaurá-lo, o que reflete a sua importância duradoura para o património de Okinawa."}, "qrc:/gcompris/src/activities/explore_farm_animals/resource/animals/chicken.webp": {"title": "Galinha", "description": "A galinha cacareja. As galinhas domésticas têm asas, mas não conseguem voar longas distâncias. Têm uma crista na cabeça."}, "qrc:/gcompris/src/activities/explore_farm_animals/resource/animals/dog.webp": {"title": "Cão", "description": "O cão ladra. Os cães são provavelmente a espécie domesticada mais antiga e descendem dos lobos."}, "qrc:/gcompris/src/activities/explore_world_animals/resource/animals/giraffe.webp": {"title": "Girafa", "description": "A girafa vive em África e é o mamífero mais alto do mundo. Só as suas pernas, que têm normalmente 1,80 metros de comprimento, são maiores que a maioria dos humanos!"}, "qrc:/gcompris/src/activities/explore_monuments/resource/france/arlesAmphitheater.webp": {"title": "Anfiteatro de Arles", "description": "O anfiteatro romano de Arles foi construído por volta do ano 90 d. C. e podia acolher cerca de 21 000 espectadores. As galerias circulares, as passagens e as escadas permitiam a circulação do público num edifício de grandes dimensões. É um dos monumentos mais conhecidos da cidade."}, "qrc:/gcompris/src/activities/explore_monuments/resource/usa/cabrillo.webp": {"title": "Cabrillo", "description": "O Monumento Nacional de Cabrillo, em Point Loma, San Diego, comemora a viagem de Juan Rodríguez Cabrillo à costa ocidental dos atuais Estados Unidos. O seu local e data de nascimento não são conhecidos com certeza. Ao serviço da Coroa espanhola, chegou à baía de San Diego em setembro de 1542, depois de partir do porto de Navidad, no México."}}
 property var pages: []
 property var evidence: ({})
 Component.onCompleted: {ApplicationSettings.isAudioVoicesEnabled=true;ApplicationSettings.isAudioEffectsEnabled=true;}
 function all(root){var result=[root];if(root.children)for(var child of root.children)result=result.concat(all(child));return result;}
 function click(item){var p=item.mapToItem(pageView,item.width/2,item.height/2);verify(p.x>=0&&p.y>=0&&p.x<pageView.width&&p.y<pageView.height,'Painted control inside viewport');mouseClick(item,item.width/2,item.height/2,Qt.LeftButton,Qt.NoModifier,10);wait(50);}
 function icon(suffix){var image=all(bar).find(child=>child.source!==undefined&&String(child.source).endsWith(suffix)&&child.visible);verify(image!==undefined,suffix);click(image);wait(400);}
 function spots(){return all(activityBackground).filter(node=>node.source!==undefined && /\/(question|key|suitcase|cat|chicken|cow|dog|duck|horse|owl|pig|sheep)\.svg$/.test(String(node.source))&&node.visible&&node.width>0&&node.height>0);}
 function continueSound(){if(audioNeededDialog.active){var button=all(audioNeededDialog.item).find(node=>node.text!==undefined&&String(node.text)===String(audioNeededDialog.item.button2Text)&&node.clicked!==undefined);verify(button!==undefined);click(button);wait(300);}}
 function test_presentations(){
  wait(1200);continueSound();
  evidence={initial:{map:bar.level,stage:score.currentSubLevel,totalStages:score.numberOfSubLevels,totalMaps:activity.numberOfLevel},spots:spots().length};
  for(var map=1;map<=activity.numberOfLevel;map++){
  compare(bar.level,map);compare(score.currentSubLevel,1);
  var cards=spots();verify(cards.length>0);
  for(var i=0;i<cards.length;i++){
   tryCompare(cards[i],'status',Image.Ready,2000);var point=cards[i].mapToItem(pageView,cards[i].width/2,cards[i].height/2);click(cards[i]);tryCompare(descriptionPanel,'visible',true,2000);wait(1300);
   var images=all(descriptionPanel).filter(node=>node.source!==undefined&&String(node.source).endsWith('.webp'));verify(images.length===1);tryCompare(images[0],'status',Image.Ready,2000);
   pages.push({map:map,title:String(descriptionPanel.title),description:String(descriptionPanel.description),image:String(images[0].source),mapImage:String(bg.source),x:point.x/pageView.width,y:point.y/pageView.height,audio:String(activity.audioVoices.source)});
   grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/language-exact-green-explore_monuments/presentation-m'+map+'-'+i+'.png');
   keyClick(Qt.Key_Escape);tryCompare(descriptionPanel,'visible',false,2000);wait(100);
  }
  wait(2200);if(map<activity.numberOfLevel){var steps=0;while(bar.level===map&&steps++<3)icon('bar_next.svg');compare(bar.level,map+1);wait(600);}
  }
  var reviewed=pages.filter(page=>expectedTexts[page.image]!==undefined);verify(reviewed.length>0,'Nonempty reviewed presentation coverage');verify(reviewed.every(page=>page.title===expectedTexts[page.image].title&&page.description===expectedTexts[page.image].description),'PT-PT meaning, spelling and names match the reviewed visible presentations');
  evidence.after={map:bar.level,stage:score.currentSubLevel,okVisible:okButton.visible};grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/language-exact-green-explore_monuments/visited.png');
 }
 function cleanupTestCase(){console.log('NATIVE_RESULT',JSON.stringify({failures:qtest_results.failCount,passes:qtest_results.passCount,pages:pages,evidence:evidence}));}
}

    }
}
