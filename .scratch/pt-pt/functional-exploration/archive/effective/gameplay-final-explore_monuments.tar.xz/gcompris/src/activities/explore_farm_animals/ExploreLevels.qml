import QtTest
/* GCompris - ExploreLevels.qml
*
* SPDX-FileCopyrightText: 2015 Ayush Agrawal <ayushagrawal288@gmail.com>
*
* Authors:
*   Beth Hadley <bethmhadley@gmail.com> (GTK+ version)
*   Ayush Agrawal <ayushagrawal288@gmail.com> (Qt Quick port)
*   Djalil MESLI <djalilmesli@gmail.com> (Qt Quick port)
*   Johnny Jazeix <jazeix@gmail.com> (Qt Quick port)
*
*   SPDX-License-Identifier: GPL-3.0-or-later
*/

import QtQuick
import core 1.0

import "../../core"
import "explore-level.js" as Activity

ActivityBase {
    id: activity

    property string url
    property bool hasAudioQuestions
    property bool needsVoices: false

    onStart: focus = true
    onStop: {}

    isMusicalActivity: needsVoices

     onActivityNextLevel: {
         Activity.nextLevel()
    }

    pageComponent: Image {
        id: activityBackground
        source: "qrc:/gcompris/src/activities/chess/resource/background-wood.svg"
        width: parent.width
        height: parent.height
        sourceSize.width: width
        sourceSize.height: height

        // if audio is disabled, we display a dialog to tell users this activity requires audio anyway
        property bool audioDisabled: false

        /* In order to accept any screen ratio the play area is always a 1000x1000
         * square and is centered in a big background image that is 3000x3000
         */

        Image {
            id: bg
            source: dataset.item.backgroundImage
            sourceSize.width: width
            sourceSize.height: width
            width: 3000 * activityBackground.playRatio
            height: width
            anchors.centerIn: parent
        }

        property int playX: (activity.width - playWidth) / 2
        property int playY: (activity.height - playHeight) / 2
        property int playWidth: Math.min(activity.height - (bar.height * 2.2), activity.width)
        property int playHeight: playWidth
        property double playRatio: playWidth / 1000

        focus: true

        signal start
        signal stop
        signal voiceDone

        Component.onCompleted: {
            activity.start.connect(start)
            activity.stop.connect(stop)
        }

        // Add here the QML items you need to access in javascript
        QtObject {
            id: items

            property GCAudio audioVoices: activity.audioVoices
            property alias goodAnswerSound: goodAnswerSound
            property alias badAnswerSound: badAnswerSound
            property Item main: activity.main
            property int currentLevel: activity.currentLevel
            onCurrentLevelChanged: activity.currentLevel = currentLevel
            property int numberOfLevel: activity.numberOfLevel
            onNumberOfLevelChanged: activity.numberOfLevel = numberOfLevel
            property alias bonus: bonus
            property alias score: score
            property alias progressbar: progressbar
            property alias errorRectangle: errorRectangle
            property alias dataModel: dataModel
            property alias dataset: dataset
            property alias descriptionPanel: descriptionPanel
            property bool hasAudioQuestions: activity.hasAudioQuestions
            property var questionOrder
            property var currentQuestion: ""
            property alias okButton: okButton
            property bool bonusPlaying: false
            property bool buttonsBlocked: false
            property bool descriptionBonusDone: false
        }

        Loader {
            id: dataset
            asynchronous: false
            onStatusChanged: {
                if (status == Loader.Ready) {
                    // create table of size N filled with numbers from 0 to N
                    items.questionOrder = Array.apply(null, {length: items.dataModel.count}).map(Number.call, Number)
                }
            }
        }

        onStart: {
            activity.audioVoices.done.connect(voiceDone)
            Activity.start(items, url)
            if(activity.needsVoices === true) {
                if(!ApplicationSettings.isAudioVoicesEnabled || !ApplicationSettings.isAudioEffectsEnabled)
                    activityBackground.audioDisabled = true
            }
        }
        onStop: { Activity.stop() }

        Keys.onEscapePressed: {
            descriptionPanel.visible ? descriptionPanel.closeDescriptionPanel() : home()
        }

        onVoiceDone: {
            if(items.bonusPlaying) {
                items.bonusPlaying = false;
                Activity.repeat();
            }
        }

        GCSoundEffect {
            id: goodAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/completetask.wav"
        }

        GCSoundEffect {
            id: badAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/crash.wav"
        }

        GCTextPanel {
            id: instructionPanel
            panelWidth: parent.width - 3 * GCStyle.baseMargins - score.width
            panelHeight: 50 * ApplicationInfo.ratio
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.horizontalCenterOffset: (-score.width - GCStyle.baseMargins) * 0.5
            anchors.top: parent.top
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: (dataset.item && items.score.currentSubLevel - 1 != items.score.numberOfSubLevels  && items.score.currentSubLevel != 0) ? dataset.item.instructions[items.score.currentSubLevel - 1].text : ""
            color: GCStyle.lightBg
            border.color: GCStyle.blueBorder
            border.width: GCStyle.thinBorder
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
        }

        GCTextPanel {
            id: questionPanel
            panelWidth: instructionPanel.panelWidth
            panelHeight: instructionPanel.panelHeight
            anchors.horizontalCenter: instructionPanel.horizontalCenter
            anchors.top: instructionPanel.bottom
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: items.currentQuestion ? items.currentQuestion.text2 : ""
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
            color: GCStyle.lighterBg
            border.color: GCStyle.lightGrayBorder
            visible: items.score.currentSubLevel == 3 || (items.score.currentSubLevel == 2 && !items.hasAudioQuestions)

        }

        Score {
            id: score
            z: 1
            isScoreCounter: false
            anchors {
                bottom: undefined
                right: parent.right
                top: parent.top
                margins: GCStyle.baseMargins
            }
        }

        BarButton {
            id: repeatItem
            source: "qrc:/gcompris/src/core/resource/bar_repeat.svg";
            width: Math.min(GCStyle.bigButtonHeight, score.width)
            anchors.top: score.bottom
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            visible: items.score.currentSubLevel == 2 && activity.hasAudioQuestions //&& ApplicationSettings.isAudioVoicesEnabled
            onClicked: {
                if(!items.audioVoices.isPlaying()) {
                    Activity.repeat();
                }
            }
        }

        Repeater {
            id: dataModel
            model: dataset && dataset.item && dataset.item.tab ? dataset.item.tab.length : 0
            AnimalLevels {
                questionId: index
                source: dataset.item.tab[index].image
                x: Math.round(activityBackground.playX + activityBackground.playWidth * dataset.item.tab[index].x - width / 2)
                y: Math.round(activityBackground.playY + activityBackground.playHeight * dataset.item.tab[index].y - height / 2)
                width: Math.round(activityBackground.playWidth * dataset.item.tab[index].width)
                height: Math.round(activityBackground.playHeight * dataset.item.tab[index].height)
                title: dataset.item.tab[index].title
                description: dataset.item.tab[index].text
                imageSource: dataset.item.tab[index].image2
                question: dataset.item.tab[index].text2
                audio: dataset.item.tab[index].audio !== undefined ? dataset.item.tab[index].audio : ""
                Component.onCompleted: {
                    displayDescription.connect(displayDescriptionItem)
                }
            }
        }

        function displayDescriptionItem(animal) {
            descriptionPanel.title = animal.title
            descriptionPanel.description = animal.description
            descriptionPanel.imageSource = animal.imageSource
            descriptionPanel.visible = true
            descriptionPanel.showDescriptionPanel()
        }

        AnimalDescriptionLevels {
            id: descriptionPanel
            width: activityBackground.width
            height: activityBackground.height - bar.height * 1.2
            z: instructionPanel.z + 1
        }

        Score {
            id: progressbar
            visible: items.score.currentSubLevel != 1
            anchors.bottom: bar.top
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            onStop: Activity.nextSubSubLevel();
        }

        Image {
            id: okButton
            visible: false
            source:"qrc:/gcompris/src/core/resource/bar_ok.svg"
            sourceSize.width: GCStyle.bigButtonHeight
            fillMode: Image.PreserveAspectFit
            anchors.right: parent.right
            anchors.bottom: progressbar.top
            anchors.margins: GCStyle.baseMargins
            MouseArea {
                anchors.fill: parent
                onClicked: Activity.nextLevel()
            }
        }

        ErrorRectangle {
            id: errorRectangle
            width: 0
            height: 0
            imageSize: GCStyle.smallButtonHeight
            function releaseControls() {
                items.buttonsBlocked = false;
            }
        }


        DialogHelp {
            id: dialogHelp
            onClose: home()
        }

        Bar {
            id: bar
            level: items.currentLevel + 1
            content: BarEnumContent { value: help | home | level | reload }
            onHelpClicked: {
                displayDialog(dialogHelp)
            }
            onPreviousLevelClicked: Activity.previousLevel()
            onNextLevelClicked: Activity.nextLevel()
            onHomeClicked: activity.home()
            onReloadClicked: Activity.initLevel()
        }
        Bonus {
            id: bonus
            onWin: {
                if(progressbar.visible)
                    Activity.nextLevel();
                else {
                    okButton.visible = true;
                    items.buttonsBlocked = false;
                }
            }
        }

        Loader {
            id: audioNeededDialog
            sourceComponent: GCDialog {
                parent: activity
                isDestructible: false
                message: qsTr("This activity requires sound, so it will play some sounds even if the audio voices or effects are disabled in the main configuration.")
                button1Text: qsTr("Quit")
                button2Text: qsTr("Continue")
                onButton1Hit: activity.home();
                onClose: {
                    activityBackground.audioDisabled = false;
                }
            }
            anchors.fill: parent
            focus: true
            active: activityBackground.audioDisabled
            onStatusChanged: if (status == Loader.Ready) item.start()
        }
// SPDX-License-Identifier: GPL-3.0-or-later
TestCase {
 id: campaign
 name: 'LearnFromVisiblePresentationsAndCompleteQuizzes'
 when: activity.visible
 property var playbacks: []
 property var pages: []
 property var questions: []
 property var transitions: []
 property var evidence: ({wins:0})
 property int readyEvents: 0
 Component.onCompleted: {ApplicationSettings.isAudioVoicesEnabled=true;ApplicationSettings.isAudioEffectsEnabled=true;}
 Connections {target:activity.audioVoices;function onSourceChanged(){var source=String(activity.audioVoices.source);if(source)campaign.playbacks.push(source);}}
 Connections {target:bonus;function onWin(){campaign.evidence.wins++;}}
 Connections {target:progressbar;function onStop(){campaign.readyEvents++;}}
 function all(root){var result=[root];if(root.children)for(var child of root.children)result=result.concat(all(child));return result;}
 function click(item){var p=item.mapToItem(pageView,item.width/2,item.height/2);verify(p.x>=0&&p.y>=0&&p.x<pageView.width&&p.y<pageView.height,'Painted control inside viewport');mouseClick(item,item.width/2,item.height/2,Qt.LeftButton,Qt.NoModifier,10);wait(50);}
 function icon(suffix){var image=all(bar).find(child=>child.source!==undefined&&String(child.source).endsWith(suffix)&&child.visible);verify(image!==undefined,suffix);click(image);wait(400);}
 function spots(){return all(activityBackground).filter(node=>node.source!==undefined && /\/(question|key|suitcase|cat|chicken|cow|dog|duck|horse|owl|pig|sheep)\.svg$/.test(String(node.source))&&node.visible&&node.width>0&&node.height>0);}
 function continueSound(){if(audioNeededDialog.active){var button=all(audioNeededDialog.item).find(node=>node.text!==undefined&&String(node.text)===String(audioNeededDialog.item.button2Text)&&node.clicked!==undefined);verify(button!==undefined);click(button);wait(300);}}

 function factsFor(map,cards){
  var learned=[];
  for(var i=0;i<cards.length;i++){
   tryCompare(cards[i],'status',Image.Ready,2000);var point=cards[i].mapToItem(pageView,cards[i].width/2,cards[i].height/2);click(cards[i]);tryCompare(descriptionPanel,'visible',true,2000);wait(1300);
   var image=all(descriptionPanel).find(node=>node.source!==undefined&&String(node.source).endsWith('.webp'));verify(image!==undefined);tryCompare(image,'status',Image.Ready,2000);
   var page={map:map,title:String(descriptionPanel.title),description:String(descriptionPanel.description),image:String(image.source),mapImage:String(bg.source),x:point.x/pageView.width,y:point.y/pageView.height,audio:String(activity.audioVoices.source)};
   pages.push(page);learned.push(page);grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/gameplay-final-explore_monuments/presentation-m'+map+'-'+i+'.png');
   keyClick(Qt.Key_Escape);tryCompare(descriptionPanel,'visible',false,2000);wait(100);
  }
  return learned;
 }
 function meaning(prompt,learned){
  var normal=text=>text.toLowerCase().replace(/^(a|o|as|os) /,'').replace(/[.,]/g,'');var named=learned.filter(page=>normal(page.title)===normal(prompt)||normal(page.title.split(',')[0])===normal(prompt));if(named.length===1)return named[0];
  var rules=[[/lã/,'Ovelha'],[/lama/,'Porco'],[/noite|noturn|nocturn/,'Coruja'],[/lobo/,'Cão'],[/crista|ovos/,'Galinha'],[/ratos|roedores|ronron/,'Gato'],[/nadar|nada|água|membrana/,'Pato'],[/leite|paladar|odores|papilas|sabores|20[ \u00a0]?000/,'Vaca'],[/correr|equilíbrio|cascos|relinch/,'Cavalo']];
  var matches=rules.filter(rule=>rule[0].test(prompt.toLowerCase())).map(rule=>rule[1]);verify(matches.length===1,'Question must follow a unique taught fact: '+prompt);return learned.find(page=>page.title===matches[0]);
 }
 function atPosition(page){var cards=spots();return cards.find(card=>{var p=card.mapToItem(pageView,card.width/2,card.height/2);return Math.abs(p.x/pageView.width-page.x)<0.005&&Math.abs(p.y/pageView.height-page.y)<0.005;});}
 function quiz(map,stage,learned,audio){
  compare(score.currentSubLevel,stage);compare(progressbar.currentSubLevel,0);compare(progressbar.numberOfSubLevels,learned.length);
  for(var n=0;n<learned.length;n++){
   wait(250);var prompt=audio?'':String(questionPanel.textItem.text);var sound=audio?String(activity.audioVoices.source):'';
   evidence.pendingPrompt=prompt;var chosen=audio?learned.find(page=>page.audio===sound):meaning(prompt,learned);verify(chosen!==undefined,'Question is solvable from the presentations: '+prompt+' '+sound);
   var row={map:map,stage:stage,kind:audio?'audio':'text',prompt:prompt,audio:sound,selected:chosen.title,x:chosen.x,y:chosen.y,before:progressbar.currentSubLevel};
   if(n===0){
    var wrong=learned.find(page=>page.title!==chosen.title);var wrongCard=atPosition(wrong);verify(wrongCard!==undefined);click(wrongCard);wait(150);row.wrong={selected:wrong.title,unchanged:progressbar.currentSubLevel===row.before};compare(progressbar.currentSubLevel,row.before);grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/gameplay-final-explore_monuments/wrong-m'+map+'-s'+stage+'.png');tryCompare(errorRectangle,'opacity',0,2500);wait(80);
    if(audio){click(repeatItem);wait(250);compare(String(activity.audioVoices.source),sound);row.repeated=true;}
   }
   var card=atPosition(chosen);verify(card!==undefined);var events=readyEvents;click(card);tryVerify(()=>progressbar.currentSubLevel===row.before+1,2000);row.after=progressbar.currentSubLevel;questions.push(row);
   if(n===learned.length-1){grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/gameplay-final-explore_monuments/quiz-complete-m'+map+'-s'+stage+'.png');tryVerify(()=>score.currentSubLevel!==stage||bar.level!==map,8000);transitions.push({map:map,stage:stage,nextMap:bar.level,nextStage:score.currentSubLevel,natural:true});}
   else {tryVerify(()=>readyEvents>events,2500);}
  }
 }
 function test_complete_all_visible_stages(){
  wait(1200);continueSound();var id=activity.activityInfo.shortName();var expected=id==='explore_monuments'?[7,11,10,7,10,4,6,6,4]:id==='explore_world_animals'?[5,5,5]:[9];var audio=id==='explore_farm_animals'||id==='explore_world_music';
  compare(activity.numberOfLevel,expected.length);
  for(var map=1;map<=expected.length;map++){
   compare(bar.level,map);compare(score.currentSubLevel,1);var cards=spots();compare(cards.length,expected[map-1]);var wins=evidence.wins;grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/gameplay-final-explore_monuments/map-m'+map+'.png');var learned=factsFor(map,cards);tryVerify(()=>evidence.wins>wins&&okButton.visible,5000);click(okButton);wait(350);compare(score.currentSubLevel,2);
   if(audio)quiz(map,2,learned,true);
   quiz(map,audio?3:2,learned,false);
  }
  compare(bar.level,1);compare(score.currentSubLevel,1);grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/gameplay-final-explore_monuments/natural-wrap.png');evidence.naturalWrap=true;verify(questions.every(row=>!/(amostras de sabor|nocturn)/.test(row.prompt)),'Question wording uses PT-PT current spelling and taught meaning');
 }
 function cleanupTestCase(){if(qtest_results.failCount)grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/gameplay-final-explore_monuments/failure.png');console.log('NATIVE_RESULT',JSON.stringify({failures:qtest_results.failCount,passes:qtest_results.passCount,pages:pages,questions:questions,transitions:transitions,evidence:evidence,playbacks:playbacks}));}
}

    }
}
