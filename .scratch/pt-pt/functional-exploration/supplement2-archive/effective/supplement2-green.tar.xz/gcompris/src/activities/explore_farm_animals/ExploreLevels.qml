import QtTest
/* GCompris - ExploreLevels.qml
*
* SPDX-FileCopyrightText: 2015 Ayush Agrawal <ayushagrawal288@gmail.com>
*
* Authors:
*   Beth Hadley <bethmhadley@gmail.com> (GTK+ version)
*   Ayush Agrawal <ayushagrawal288@gmail.com> (Qt Quick port)
*   Djalil MESLI <djalilmesli@gmail.com> (Qt Quick port)
*   Johnny Jazeix <jazeix@gmail.com> (Qt Quick port)
*
*   SPDX-License-Identifier: GPL-3.0-or-later
*/

import QtQuick
import core 1.0

import "../../core"
import "explore-level.js" as Activity

ActivityBase {
    id: activity

    property string url
    property bool hasAudioQuestions
    property bool needsVoices: false

    onStart: focus = true
    onStop: {}

    isMusicalActivity: needsVoices

     onActivityNextLevel: {
         Activity.nextLevel()
    }

    pageComponent: Image {
        id: activityBackground
        source: "qrc:/gcompris/src/activities/chess/resource/background-wood.svg"
        width: parent.width
        height: parent.height
        sourceSize.width: width
        sourceSize.height: height

        // if audio is disabled, we display a dialog to tell users this activity requires audio anyway
        property bool audioDisabled: false

        /* In order to accept any screen ratio the play area is always a 1000x1000
         * square and is centered in a big background image that is 3000x3000
         */

        Image {
            id: bg
            source: dataset.item.backgroundImage
            sourceSize.width: width
            sourceSize.height: width
            width: 3000 * activityBackground.playRatio
            height: width
            anchors.centerIn: parent
        }

        property int playX: (activity.width - playWidth) / 2
        property int playY: (activity.height - playHeight) / 2
        property int playWidth: Math.min(activity.height - (bar.height * 2.2), activity.width)
        property int playHeight: playWidth
        property double playRatio: playWidth / 1000

        focus: true

        signal start
        signal stop
        signal voiceDone

        Component.onCompleted: {
            activity.start.connect(start)
            activity.stop.connect(stop)
        }

        // Add here the QML items you need to access in javascript
        QtObject {
            id: items

            property GCAudio audioVoices: activity.audioVoices
            property alias goodAnswerSound: goodAnswerSound
            property alias badAnswerSound: badAnswerSound
            property Item main: activity.main
            property int currentLevel: activity.currentLevel
            onCurrentLevelChanged: activity.currentLevel = currentLevel
            property int numberOfLevel: activity.numberOfLevel
            onNumberOfLevelChanged: activity.numberOfLevel = numberOfLevel
            property alias bonus: bonus
            property alias score: score
            property alias progressbar: progressbar
            property alias errorRectangle: errorRectangle
            property alias dataModel: dataModel
            property alias dataset: dataset
            property alias descriptionPanel: descriptionPanel
            property bool hasAudioQuestions: activity.hasAudioQuestions
            property var questionOrder
            property var currentQuestion: ""
            property alias okButton: okButton
            property bool bonusPlaying: false
            property bool buttonsBlocked: false
            property bool descriptionBonusDone: false
        }

        Loader {
            id: dataset
            asynchronous: false
            onStatusChanged: {
                if (status == Loader.Ready) {
                    // create table of size N filled with numbers from 0 to N
                    items.questionOrder = Array.apply(null, {length: items.dataModel.count}).map(Number.call, Number)
                }
            }
        }

        onStart: {
            activity.audioVoices.done.connect(voiceDone)
            Activity.start(items, url)
            if(activity.needsVoices === true) {
                if(!ApplicationSettings.isAudioVoicesEnabled || !ApplicationSettings.isAudioEffectsEnabled)
                    activityBackground.audioDisabled = true
            }
        }
        onStop: { Activity.stop() }

        Keys.onEscapePressed: {
            descriptionPanel.visible ? descriptionPanel.closeDescriptionPanel() : home()
        }

        onVoiceDone: {
            if(items.bonusPlaying) {
                items.bonusPlaying = false;
                Activity.repeat();
            }
        }

        GCSoundEffect {
            id: goodAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/completetask.wav"
        }

        GCSoundEffect {
            id: badAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/crash.wav"
        }

        GCTextPanel {
            id: instructionPanel
            panelWidth: parent.width - 3 * GCStyle.baseMargins - score.width
            panelHeight: 50 * ApplicationInfo.ratio
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.horizontalCenterOffset: (-score.width - GCStyle.baseMargins) * 0.5
            anchors.top: parent.top
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: (dataset.item && items.score.currentSubLevel - 1 != items.score.numberOfSubLevels  && items.score.currentSubLevel != 0) ? dataset.item.instructions[items.score.currentSubLevel - 1].text : ""
            color: GCStyle.lightBg
            border.color: GCStyle.blueBorder
            border.width: GCStyle.thinBorder
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
        }

        GCTextPanel {
            id: questionPanel
            panelWidth: instructionPanel.panelWidth
            panelHeight: instructionPanel.panelHeight
            anchors.horizontalCenter: instructionPanel.horizontalCenter
            anchors.top: instructionPanel.bottom
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: items.currentQuestion ? items.currentQuestion.text2 : ""
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
            color: GCStyle.lighterBg
            border.color: GCStyle.lightGrayBorder
            visible: items.score.currentSubLevel == 3 || (items.score.currentSubLevel == 2 && !items.hasAudioQuestions)

        }

        Score {
            id: score
            z: 1
            isScoreCounter: false
            anchors {
                bottom: undefined
                right: parent.right
                top: parent.top
                margins: GCStyle.baseMargins
            }
        }

        BarButton {
            id: repeatItem
            source: "qrc:/gcompris/src/core/resource/bar_repeat.svg";
            width: Math.min(GCStyle.bigButtonHeight, score.width)
            anchors.top: score.bottom
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            visible: items.score.currentSubLevel == 2 && activity.hasAudioQuestions //&& ApplicationSettings.isAudioVoicesEnabled
            onClicked: {
                if(!items.audioVoices.isPlaying()) {
                    Activity.repeat();
                }
            }
        }

        Repeater {
            id: dataModel
            model: dataset && dataset.item && dataset.item.tab ? dataset.item.tab.length : 0
            AnimalLevels {
                questionId: index
                source: dataset.item.tab[index].image
                x: Math.round(activityBackground.playX + activityBackground.playWidth * dataset.item.tab[index].x - width / 2)
                y: Math.round(activityBackground.playY + activityBackground.playHeight * dataset.item.tab[index].y - height / 2)
                width: Math.round(activityBackground.playWidth * dataset.item.tab[index].width)
                height: Math.round(activityBackground.playHeight * dataset.item.tab[index].height)
                title: dataset.item.tab[index].title
                description: dataset.item.tab[index].text
                imageSource: dataset.item.tab[index].image2
                question: dataset.item.tab[index].text2
                audio: dataset.item.tab[index].audio !== undefined ? dataset.item.tab[index].audio : ""
                Component.onCompleted: {
                    displayDescription.connect(displayDescriptionItem)
                }
            }
        }

        function displayDescriptionItem(animal) {
            descriptionPanel.title = animal.title
            descriptionPanel.description = animal.description
            descriptionPanel.imageSource = animal.imageSource
            descriptionPanel.visible = true
            descriptionPanel.showDescriptionPanel()
        }

        AnimalDescriptionLevels {
            id: descriptionPanel
            width: activityBackground.width
            height: activityBackground.height - bar.height * 1.2
            z: instructionPanel.z + 1
        }

        Score {
            id: progressbar
            visible: items.score.currentSubLevel != 1
            anchors.bottom: bar.top
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            onStop: Activity.nextSubSubLevel();
        }

        Image {
            id: okButton
            visible: false
            source:"qrc:/gcompris/src/core/resource/bar_ok.svg"
            sourceSize.width: GCStyle.bigButtonHeight
            fillMode: Image.PreserveAspectFit
            anchors.right: parent.right
            anchors.bottom: progressbar.top
            anchors.margins: GCStyle.baseMargins
            MouseArea {
                anchors.fill: parent
                onClicked: Activity.nextLevel()
            }
        }

        ErrorRectangle {
            id: errorRectangle
            width: 0
            height: 0
            imageSize: GCStyle.smallButtonHeight
            function releaseControls() {
                items.buttonsBlocked = false;
            }
        }


        DialogHelp {
            id: dialogHelp
            onClose: home()
        }

        Bar {
            id: bar
            level: items.currentLevel + 1
            content: BarEnumContent { value: help | home | level | reload }
            onHelpClicked: {
                displayDialog(dialogHelp)
            }
            onPreviousLevelClicked: Activity.previousLevel()
            onNextLevelClicked: Activity.nextLevel()
            onHomeClicked: activity.home()
            onReloadClicked: Activity.initLevel()
        }
        Bonus {
            id: bonus
            onWin: {
                if(progressbar.visible)
                    Activity.nextLevel();
                else {
                    okButton.visible = true;
                    items.buttonsBlocked = false;
                }
            }
        }

        Loader {
            id: audioNeededDialog
            sourceComponent: GCDialog {
                parent: activity
                isDestructible: false
                message: qsTr("This activity requires sound, so it will play some sounds even if the audio voices or effects are disabled in the main configuration.")
                button1Text: qsTr("Quit")
                button2Text: qsTr("Continue")
                onButton1Hit: activity.home();
                onClose: {
                    activityBackground.audioDisabled = false;
                }
            }
            anchors.fill: parent
            focus: true
            active: activityBackground.audioDisabled
            onStatusChanged: if (status == Loader.Ready) item.start()
        }
// SPDX-License-Identifier: GPL-3.0-or-later
TestCase {
 name: 'EightObservedTranslationMeanings'
 when:activity.visible
 property var targets: [{"image": "qrc:/gcompris/src/activities/explore_monuments/resource/india/gatewayofIndia.webp", "map": 2, "title": "Portão da Índia", "x": 0.26125, "y": 0.58375, "old": "O Portão da Índia é um dos marcos mais únicos da Índia, situado na cidade de Mumbai. A estrutura colossal foi construída em 1924. Localizada na ponta do Apollo Bunder, o portão tem uma vista sobre o porto de Mumbai, rodeado pelo Mar Árabe no distrito de Colaba. O Portão da Índia é um monumento que marca os portos principais da Índia e é uma atração turística importante para os visitantes que chegam à Índia pela primeira vez.", "new": "O Portão da Índia é um dos marcos mais únicos da Índia, situado na cidade de Mumbai. A estrutura colossal foi construída em 1924. Localizado na ponta do Apollo Bunder, o portão tem uma vista sobre o porto de Mumbai, rodeado pelo Mar Árabe no distrito de Colaba. O Portão da Índia é um monumento que marca os portos principais da Índia e é uma atração turística importante para os visitantes que chegam à Índia pela primeira vez."}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/germany/neuschwansteinCastle.webp", "map": 4, "title": "Castelo de Neuschwanstein", "x": 0.51875, "y": 0.83125, "old": "O pináculo dos castelos de contos de fadas, o Neuschwanstein situa-se uma colina rugosa perto de Füssen, no Sudoeste da Baviera. Foi a inspiração para os castelos da Bela Adormecida nos parques da Disneylândia. O castelo foi encomendado pelo Rei Ludwig II da Baviera, o qual foi declarado como louco quando o castelo estava perto da sua conclusão em 1886, sendo encontrado morto alguns dias depois. Neuschwanstein é o edifício mais fotografado do país e é uma das mais conhecidas atrações turísticas na Alemanha.", "new": "O pináculo dos castelos de contos de fadas, o Neuschwanstein situa-se numa colina escarpada perto de Füssen, no Sudoeste da Baviera. Foi a inspiração para os castelos da Bela Adormecida nos parques da Disneylândia. O castelo foi encomendado pelo Rei Ludwig II da Baviera, o qual foi declarado como louco quando o castelo estava perto da sua conclusão em 1886, sendo encontrado morto alguns dias depois. Neuschwanstein é o edifício mais fotografado do país e é uma das mais conhecidas atrações turísticas na Alemanha."}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/usa/castillodeSanMarcos.webp", "map": 5, "title": "Castelo de São Marcos", "x": 0.69625, "y": 0.6275, "old": "Estendendo-se em mais de 8 hectares de St. Augustine, na Flórida, o Castelo de São Marcos foi terminado como sendo o forte defensivo da cidade em 1695, quando a Flórida ainda era um território Espanhol. Construído a partir da pedra rara que é a coquina, o castelo em forma de estrela também é o mais antigo forte senhorial do país.", "new": "Estendendo-se em mais de 8 hectares de St. Augustine, na Flórida, o Castelo de São Marcos foi terminado como sendo o forte defensivo da cidade em 1695, quando a Flórida ainda era um território Espanhol. Construído a partir da pedra rara que é a coquina, o castelo em forma de estrela também é o mais antigo forte de alvenaria do país."}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/usa/georgeWashingtonBirthplace.webp", "map": 5, "title": "Local de Nascimento de George Washington", "x": 0.755, "y": 0.52375, "old": "O Monumento Nacional de Nascimento de George Washington existe no Condado de Westmoreland, em Virgínia, nos Estados Unidos. Originalmente iniciado por John Washington, o bisavô de George Washington, George Washington nasceu aqui em 22 de fevereiro de 1732. Ele viveu lá até aos três anos, regressando mais tarde como adolescente.", "new": "O Monumento Nacional do Local de Nascimento de George Washington situa-se no condado de Westmoreland, na Virgínia, nos Estados Unidos. O seu bisavô, John Washington, estabeleceu-se nesta região no século XVII. George Washington nasceu aqui em 22 de fevereiro de 1732. Viveu neste local até aos três anos e regressou mais tarde, na adolescência."}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/usa/lincolnMemorial.webp", "map": 5, "title": "Memorial de Lincoln", "x": 0.72, "y": 0.46625, "old": "Construída em pedra branca com 36 colunas imponentes, o Memorial de Lincoln é uma das estruturas mais reconhecidas nos Estados Unidos. O memorial fica no extremo ocidental do National Mall, no Parque de Potomac Ocidental, sendo um exemplo da arquitetura Neoclássica. Oferece uma estátua solitária de 6 metros de altura de Abraham Lincoln sentado em contemplação, a qual está rodeada por câmaras laterais de ambos os lados com as inscrições do Segundo Discurso Inaugural de Lincoln e, sem dúvida o seu mais famoso discurso, o Discurso de Gettysburg.", "new": "Construído em pedra branca com 36 colunas imponentes, o Memorial de Lincoln é uma das estruturas mais reconhecidas nos Estados Unidos. O memorial fica no extremo ocidental do National Mall, no Parque de Potomac Ocidental, sendo um exemplo da arquitetura Neoclássica. Oferece uma estátua solitária de 6 metros de altura de Abraham Lincoln sentado em contemplação, a qual está rodeada por câmaras laterais de ambos os lados com as inscrições do Segundo Discurso Inaugural de Lincoln e, sem dúvida o seu mais famoso discurso, o Discurso de Gettysburg."}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/egypt/meidumPyramid.webp", "map": 6, "title": "Pirâmide de Meidum", "x": 0.5825, "y": 0.31875, "old": "Cinco milhas a Sul de Saqqara no Egito, eleva-se a misteriosa pirâmide em torre de Meidum, que nos dias de hoje pouco se parece com uma pirâmide de todo. A pirâmide foi provavelmente construída durante o reinado do faraó da 4a Dinastia Sneferu, ainda que se acredita que parte da pirâmide tenha sido iniciada pelo antecessor de Sneferu, Huni. A determinada altura da sua construção, os degraus da pirâmide foram preenchidos com uma cobertura em pedra calcária, marcando a primeira tentativa dos antigos Egípcios na construção de uma verdadeira pirâmide.", "new": "A pirâmide de Meidum situa-se na região de Beni Suef, no Egito. O faraó Sneferu, primeiro rei da IV dinastia, escolheu Meidum para construir o seu túmulo real. A construção começou como uma pirâmide de degraus e foi depois transformada numa pirâmide de faces lisas, revestida de calcário. Hoje, o núcleo restante ergue-se sobre um monte de entulho. A atribuição anterior a Huni, antecessor de Sneferu, já não corresponde ao consenso atual dos especialistas."}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/china/forbiddenCity.webp", "map": 7, "title": "Cidade Proibida", "x": 0.64375, "y": 0.4625, "old": "A Cidade Proibida, localizada no coração de Beijing (Pequim), na China, é um magnífico complexo do Palácio imperial que serviu de casa aos imperadores chineses e de centro político da nação por quase 500 anos, da Dinastia Ming (1368-1644) até ao fim da dinastia Qing (1644-1912). Construído entre 1406 e 1420, esta obra-prima arquitetónica abrange 180 hectares e apresenta mais de 980 edifícios preservados com 8.700 divisões, representativas do design palaciano chinês tradicional. Rodeado por um fosso e muralhas altas, a Cidade Proibida já foi inacessível ao público em geral, simbolizando a exclusividade do poder imperial.", "new": "A Cidade Proibida, localizada no coração de Beijing (Pequim), na China, é um magnífico complexo do Palácio imperial que serviu de casa aos imperadores chineses e de centro político da nação por quase 500 anos, da Dinastia Ming (1368-1644) até ao fim da dinastia Qing (1644-1912). Construída entre 1406 e 1420, esta obra-prima arquitetónica abrange 180 acres (cerca de 73 hectares) e apresenta mais de 980 edifícios preservados com 8 700 divisões, representativas do design palaciano chinês tradicional. Rodeada por um fosso e muralhas altas, a Cidade Proibida já foi inacessível ao público em geral, simbolizando a exclusividade do poder imperial."}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/italy/florenceCathedral.webp", "map": 8, "title": "Catedral de Florença", "x": 0.42375, "y": 0.39375, "old": "A Catedral de Florença, oficialmente conhecida como Cattedrale di Santa Maria del Fiore, é uma obra-prima de renome da arquitetura gótica e renascentista localizada em Florença, Itália. Concluída em 1436, é famosa pela sua enorme cúpula de azulejos vermelhos projetada por Filippo Brunelleschi, permanecendo uma maravilha da engenharia e um símbolo da cidade. A intricada fachada em mármore da catedral, acrescentada no século XIX, complementa os tesouros artísticos do seu interior ricamente decorado. Juntamente com o Campanário de Giotto e o Batistério de São João, faz parte do Património Mundial da Humanidade da UNESCO, e as suas características históricas, culturais e a sua importância arquitetónica atraem anualmente milhões de visitantes.", "new": "A Catedral de Florença, oficialmente conhecida como Cattedrale di Santa Maria del Fiore, é uma obra-prima de renome da arquitetura gótica e renascentista localizada em Florença, Itália. Concluída em 1436, é famosa pela sua enorme cúpula revestida de telhas de terracota vermelha projetada por Filippo Brunelleschi, permanecendo uma maravilha da engenharia e um símbolo da cidade. A intricada fachada em mármore da catedral, acrescentada no século XIX, complementa os tesouros artísticos do seu interior ricamente decorado. Juntamente com o Campanário de Giotto e o Batistério de São João, faz parte do Património Mundial da Humanidade da UNESCO, e as suas características históricas, culturais e a sua importância arquitetónica atraem anualmente milhões de visitantes."}]
 property var pages: []
 function all(root){var result=[root];if(root.children)for(var child of root.children)result=result.concat(all(child));return result;}
 function click(item){var p=item.mapToItem(pageView,item.width/2,item.height/2);verify(p.x>=0&&p.y>=0&&p.x<pageView.width&&p.y<pageView.height,'Painted control inside viewport');mouseClick(item,item.width/2,item.height/2,Qt.LeftButton,Qt.NoModifier,10);wait(50);}
 function icon(suffix){var image=all(bar).find(child=>child.source!==undefined&&String(child.source).endsWith(suffix)&&child.visible);verify(image!==undefined,suffix);click(image);wait(400);}
 function spots(){return all(activityBackground).filter(node=>node.source!==undefined && /\/(question|key|suitcase|cat|chicken|cow|dog|duck|horse|owl|pig|sheep)\.svg$/.test(String(node.source))&&node.visible&&node.width>0&&node.height>0);}
 function continueSound(){if(audioNeededDialog.active){var button=all(audioNeededDialog.item).find(node=>node.text!==undefined&&String(node.text)===String(audioNeededDialog.item.button2Text)&&node.clicked!==undefined);verify(button!==undefined);click(button);wait(300);}}

 function test_correct_eight_visible_presentations(){
  wait(1200);continueSound();
  for(var map=1;map<=8;map++){
   compare(bar.level,map);compare(score.currentSubLevel,1);
   for(var lesson of targets.filter(row=>row.map===map)){
    var card=spots().find(node=>{var point=node.mapToItem(pageView,node.width/2,node.height/2);return Math.abs(point.x/pageView.width-lesson.x)<0.005&&Math.abs(point.y/pageView.height-lesson.y)<0.005;});verify(card!==undefined);click(card);tryCompare(descriptionPanel,'visible',true,2000);wait(1300);
    var image=all(descriptionPanel).find(node=>node.source!==undefined&&String(node.source).endsWith('.webp'));verify(image!==undefined);tryCompare(image,'status',Image.Ready,2000);compare(String(image.source),lesson.image);
    pages.push({image:String(image.source),title:String(descriptionPanel.title),description:String(descriptionPanel.description),map:map});grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/supplement2-green/supplement-m'+map+'-'+(pages.length-1)+'.png');
    keyClick(Qt.Key_Escape);tryCompare(descriptionPanel,'visible',false,2000);
   }
   if(map<8){var attempts=0;while(bar.level===map&&attempts++<3)icon('bar_next.svg');compare(bar.level,map+1);wait(500);}
  }
  compare(pages.length,8);verify(pages.every(page=>page.description===targets.find(row=>row.image===page.image).new),'Geography, geology and dwellings preserve the source meaning in PT-PT');
 }
 function cleanupTestCase(){console.log('NATIVE_RESULT',JSON.stringify({failures:qtest_results.failCount,passes:qtest_results.passCount,pages:pages}));}
}

    }
}
