import QtTest
/* GCompris - ExploreLevels.qml
*
* SPDX-FileCopyrightText: 2015 Ayush Agrawal <ayushagrawal288@gmail.com>
*
* Authors:
*   Beth Hadley <bethmhadley@gmail.com> (GTK+ version)
*   Ayush Agrawal <ayushagrawal288@gmail.com> (Qt Quick port)
*   Djalil MESLI <djalilmesli@gmail.com> (Qt Quick port)
*   Johnny Jazeix <jazeix@gmail.com> (Qt Quick port)
*
*   SPDX-License-Identifier: GPL-3.0-or-later
*/

import QtQuick
import core 1.0

import "../../core"
import "explore-level.js" as Activity

ActivityBase {
    id: activity

    property string url
    property bool hasAudioQuestions
    property bool needsVoices: false

    onStart: focus = true
    onStop: {}

    isMusicalActivity: needsVoices

     onActivityNextLevel: {
         Activity.nextLevel()
    }

    pageComponent: Image {
        id: activityBackground
        source: "qrc:/gcompris/src/activities/chess/resource/background-wood.svg"
        width: parent.width
        height: parent.height
        sourceSize.width: width
        sourceSize.height: height

        // if audio is disabled, we display a dialog to tell users this activity requires audio anyway
        property bool audioDisabled: false

        /* In order to accept any screen ratio the play area is always a 1000x1000
         * square and is centered in a big background image that is 3000x3000
         */

        Image {
            id: bg
            source: dataset.item.backgroundImage
            sourceSize.width: width
            sourceSize.height: width
            width: 3000 * activityBackground.playRatio
            height: width
            anchors.centerIn: parent
        }

        property int playX: (activity.width - playWidth) / 2
        property int playY: (activity.height - playHeight) / 2
        property int playWidth: Math.min(activity.height - (bar.height * 2.2), activity.width)
        property int playHeight: playWidth
        property double playRatio: playWidth / 1000

        focus: true

        signal start
        signal stop
        signal voiceDone

        Component.onCompleted: {
            activity.start.connect(start)
            activity.stop.connect(stop)
        }

        // Add here the QML items you need to access in javascript
        QtObject {
            id: items

            property GCAudio audioVoices: activity.audioVoices
            property alias goodAnswerSound: goodAnswerSound
            property alias badAnswerSound: badAnswerSound
            property Item main: activity.main
            property int currentLevel: activity.currentLevel
            onCurrentLevelChanged: activity.currentLevel = currentLevel
            property int numberOfLevel: activity.numberOfLevel
            onNumberOfLevelChanged: activity.numberOfLevel = numberOfLevel
            property alias bonus: bonus
            property alias score: score
            property alias progressbar: progressbar
            property alias errorRectangle: errorRectangle
            property alias dataModel: dataModel
            property alias dataset: dataset
            property alias descriptionPanel: descriptionPanel
            property bool hasAudioQuestions: activity.hasAudioQuestions
            property var questionOrder
            property var currentQuestion: ""
            property alias okButton: okButton
            property bool bonusPlaying: false
            property bool buttonsBlocked: false
            property bool descriptionBonusDone: false
        }

        Loader {
            id: dataset
            asynchronous: false
            onStatusChanged: {
                if (status == Loader.Ready) {
                    // create table of size N filled with numbers from 0 to N
                    items.questionOrder = Array.apply(null, {length: items.dataModel.count}).map(Number.call, Number)
                }
            }
        }

        onStart: {
            activity.audioVoices.done.connect(voiceDone)
            Activity.start(items, url)
            if(activity.needsVoices === true) {
                if(!ApplicationSettings.isAudioVoicesEnabled || !ApplicationSettings.isAudioEffectsEnabled)
                    activityBackground.audioDisabled = true
            }
        }
        onStop: { Activity.stop() }

        Keys.onEscapePressed: {
            descriptionPanel.visible ? descriptionPanel.closeDescriptionPanel() : home()
        }

        onVoiceDone: {
            if(items.bonusPlaying) {
                items.bonusPlaying = false;
                Activity.repeat();
            }
        }

        GCSoundEffect {
            id: goodAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/completetask.wav"
        }

        GCSoundEffect {
            id: badAnswerSound
            source: "qrc:/gcompris/src/core/resource/sounds/crash.wav"
        }

        GCTextPanel {
            id: instructionPanel
            panelWidth: parent.width - 3 * GCStyle.baseMargins - score.width
            panelHeight: 50 * ApplicationInfo.ratio
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.horizontalCenterOffset: (-score.width - GCStyle.baseMargins) * 0.5
            anchors.top: parent.top
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: (dataset.item && items.score.currentSubLevel - 1 != items.score.numberOfSubLevels  && items.score.currentSubLevel != 0) ? dataset.item.instructions[items.score.currentSubLevel - 1].text : ""
            color: GCStyle.lightBg
            border.color: GCStyle.blueBorder
            border.width: GCStyle.thinBorder
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
        }

        GCTextPanel {
            id: questionPanel
            panelWidth: instructionPanel.panelWidth
            panelHeight: instructionPanel.panelHeight
            anchors.horizontalCenter: instructionPanel.horizontalCenter
            anchors.top: instructionPanel.bottom
            anchors.topMargin: GCStyle.baseMargins
            textItem.text: items.currentQuestion ? items.currentQuestion.text2 : ""
            textItem.color: GCStyle.darkText
            textItem.fontSize: textItem.mediumSize
            color: GCStyle.lighterBg
            border.color: GCStyle.lightGrayBorder
            visible: items.score.currentSubLevel == 3 || (items.score.currentSubLevel == 2 && !items.hasAudioQuestions)

        }

        Score {
            id: score
            z: 1
            isScoreCounter: false
            anchors {
                bottom: undefined
                right: parent.right
                top: parent.top
                margins: GCStyle.baseMargins
            }
        }

        BarButton {
            id: repeatItem
            source: "qrc:/gcompris/src/core/resource/bar_repeat.svg";
            width: Math.min(GCStyle.bigButtonHeight, score.width)
            anchors.top: score.bottom
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            visible: items.score.currentSubLevel == 2 && activity.hasAudioQuestions //&& ApplicationSettings.isAudioVoicesEnabled
            onClicked: {
                if(!items.audioVoices.isPlaying()) {
                    Activity.repeat();
                }
            }
        }

        Repeater {
            id: dataModel
            model: dataset && dataset.item && dataset.item.tab ? dataset.item.tab.length : 0
            AnimalLevels {
                questionId: index
                source: dataset.item.tab[index].image
                x: Math.round(activityBackground.playX + activityBackground.playWidth * dataset.item.tab[index].x - width / 2)
                y: Math.round(activityBackground.playY + activityBackground.playHeight * dataset.item.tab[index].y - height / 2)
                width: Math.round(activityBackground.playWidth * dataset.item.tab[index].width)
                height: Math.round(activityBackground.playHeight * dataset.item.tab[index].height)
                title: dataset.item.tab[index].title
                description: dataset.item.tab[index].text
                imageSource: dataset.item.tab[index].image2
                question: dataset.item.tab[index].text2
                audio: dataset.item.tab[index].audio !== undefined ? dataset.item.tab[index].audio : ""
                Component.onCompleted: {
                    displayDescription.connect(displayDescriptionItem)
                }
            }
        }

        function displayDescriptionItem(animal) {
            descriptionPanel.title = animal.title
            descriptionPanel.description = animal.description
            descriptionPanel.imageSource = animal.imageSource
            descriptionPanel.visible = true
            descriptionPanel.showDescriptionPanel()
        }

        AnimalDescriptionLevels {
            id: descriptionPanel
            width: activityBackground.width
            height: activityBackground.height - bar.height * 1.2
            z: instructionPanel.z + 1
        }

        Score {
            id: progressbar
            visible: items.score.currentSubLevel != 1
            anchors.bottom: bar.top
            anchors.right: parent.right
            anchors.margins: GCStyle.baseMargins
            onStop: Activity.nextSubSubLevel();
        }

        Image {
            id: okButton
            visible: false
            source:"qrc:/gcompris/src/core/resource/bar_ok.svg"
            sourceSize.width: GCStyle.bigButtonHeight
            fillMode: Image.PreserveAspectFit
            anchors.right: parent.right
            anchors.bottom: progressbar.top
            anchors.margins: GCStyle.baseMargins
            MouseArea {
                anchors.fill: parent
                onClicked: Activity.nextLevel()
            }
        }

        ErrorRectangle {
            id: errorRectangle
            width: 0
            height: 0
            imageSize: GCStyle.smallButtonHeight
            function releaseControls() {
                items.buttonsBlocked = false;
            }
        }


        DialogHelp {
            id: dialogHelp
            onClose: home()
        }

        Bar {
            id: bar
            level: items.currentLevel + 1
            content: BarEnumContent { value: help | home | level | reload }
            onHelpClicked: {
                displayDialog(dialogHelp)
            }
            onPreviousLevelClicked: Activity.previousLevel()
            onNextLevelClicked: Activity.nextLevel()
            onHomeClicked: activity.home()
            onReloadClicked: Activity.initLevel()
        }
        Bonus {
            id: bonus
            onWin: {
                if(progressbar.visible)
                    Activity.nextLevel();
                else {
                    okButton.visible = true;
                    items.buttonsBlocked = false;
                }
            }
        }

        Loader {
            id: audioNeededDialog
            sourceComponent: GCDialog {
                parent: activity
                isDestructible: false
                message: qsTr("This activity requires sound, so it will play some sounds even if the audio voices or effects are disabled in the main configuration.")
                button1Text: qsTr("Quit")
                button2Text: qsTr("Continue")
                onButton1Hit: activity.home();
                onClose: {
                    activityBackground.audioDisabled = false;
                }
            }
            anchors.fill: parent
            focus: true
            active: activityBackground.audioDisabled
            onStatusChanged: if (status == Loader.Ready) item.start()
        }
// SPDX-License-Identifier: GPL-3.0-or-later
TestCase {
 name: 'SixObservedTranslationMeanings'
 when:activity.visible
 property var targets: [{"image": "qrc:/gcompris/src/activities/explore_monuments/resource/wonders/machuPicchu.webp", "map": 1, "title": "Machu Picchu", "old": "Machu Picchu eleva-se a 2 430 m acima do nível do mar, no meio de uma floresta montanhosa tropical, com um cenário extraordinariamente bonito. Foi provavelmente a mais impressionante criação urbana do Império Inca na sua altura; as suas paredes, terraços e rampas gigantes parecem ter sido cortadas naturalmente nas escarpas de rocha contínuas. O cenário natural, nas escarpas orientais dos Andes, compõe a nascente superior do Amazonas com a sua rica diversidade de flora e fauna.", "new": "Machu Picchu eleva-se a 2 430 m acima do nível do mar, no meio de uma floresta montanhosa tropical, com um cenário extraordinariamente bonito. Foi provavelmente a mais impressionante criação urbana do Império Inca no seu apogeu; as suas paredes, terraços e rampas gigantes parecem ter sido cortadas naturalmente nas escarpas de rocha contínuas. O cenário natural, nas escarpas orientais dos Andes, abrange a bacia superior do Amazonas com a sua rica diversidade de flora e fauna.", "x": 0.3275, "y": 0.57625}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/india/qutubMinar.webp", "map": 2, "title": "Qutub Minar", "old": "O Qutub Minar, elevado a 74 metros, é o mais alto minarete de tijolos do mundo, sendo o segundo mais alto na Índia a seguir ao Fateh Burj em Mohali. O Qutub Minar, em conjunto com os monumentos antigos e medievais que o rodeiam, formam o Complexo de Qutb, que é considerado Património Mundial da Humanidade pela UNESCO. A torre localiza-se na área de Mehrauli em Deli, Índia. É feito de granito vermelho e mármore.", "new": "O Qutub Minar, elevado a 74 metros, é o mais alto minarete de tijolos do mundo, sendo o segundo mais alto na Índia a seguir ao Fateh Burj em Mohali. O Qutub Minar, em conjunto com os monumentos antigos e medievais que o rodeiam, formam o Complexo de Qutb, que é considerado Património Mundial da Humanidade pela UNESCO. A torre localiza-se na área de Mehrauli em Deli, Índia. É feito de arenito vermelho e mármore.", "x": 0.35625, "y": 0.33}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/germany/wormsCathedral.webp", "map": 4, "title": "Catedral de Worms", "old": "A Catedral de Worms (Wormser Dom), também conhecida como Catedral de São Pedro, é uma catedral Românica na cidade alemã de Worms. Uma estrutura em granito com distintas torres cónicas, a Catedral de Worms foi construída por fases, ao longo do século XII, e foi terminada na sua maioria em 1181.", "new": "A Catedral de Worms (Wormser Dom), também conhecida como Catedral de São Pedro, é uma catedral Românica na cidade alemã de Worms. Uma estrutura em arenito com distintas torres cónicas, a Catedral de Worms foi construída por fases, ao longo do século XII, e foi terminada na sua maioria em 1181.", "x": 0.3725, "y": 0.64875}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/usa/canyondeChelly.webp", "map": 5, "title": "Escarpas de Chelly", "old": "As estóicas ruínas vermelhas das Escarpas de Chelly, a Nordeste do Arizona, fazem parte por um lado do Serviço de Parques Nacionais e por outro da Nação Navajo, sendo estabelecidos como monumentos nacionais em 1931. Um conjunto de locais importantes dos antigos Nativos Americanos são preservados nos cerca de 34 000 hectares do parque, sendo que as Escarpas de Chelly também oferecem um conjunto de formações geológicas da zona Sudoeste, incluindo a Spider Rock (Rochedo da Aranha), uma espira de granito com cerca de 200 metros de altura que se eleva de forma estranha a partir do fundo da escarpa.", "new": "O Canyon de Chelly, no nordeste do Arizona, foi declarado monumento nacional em 1931. Situa-se no território da Nação Navajo e conserva locais importantes dos antigos povos indígenas americanos. Os seus cerca de 34 000 hectares incluem formações de arenito como a Spider Rock (Rochedo da Aranha), uma agulha de rocha com cerca de 244 metros de altura.", "x": 0.33125, "y": 0.5525}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/usa/castleClinton.webp", "map": 5, "title": "Castelo Clinton", "old": "Este forte redondo de granito, situado no fundo da Ilha de Manhattan antecede a Ilha de Ellis em cerca de 50 anos como sendo o primeiro ponto de verificação de imigração dos EUA. O Castelo Clinton (nps.gov/cacl) foi construído originalmente como um forte para proteger Nova Iorque de uma invasão Britânica durante a guerra de 1812, sendo convertido num monumento nacional em 1946.", "new": "Este forte circular de arenito, situado no extremo sul da ilha de Manhattan antecede a Ilha de Ellis em cerca de 50 anos como sendo o primeiro ponto de verificação de imigração dos EUA. O Castelo Clinton (nps.gov/cacl) foi construído originalmente como um forte para proteger Nova Iorque de uma invasão Britânica durante a guerra de 1812, sendo convertido num monumento nacional em 1946.", "x": 0.75875, "y": 0.41625}, {"image": "qrc:/gcompris/src/activities/explore_monuments/resource/usa/navajo.webp", "map": 5, "title": "Navajo", "old": "O Monumento Nacional Navajo é um Monumento Nacional localizado dentro da parte Noroeste do território da Nação Navajo, a Norte do Arizona, que foi estabelecido para preservar três baixos-relevos em penhasco do Povo Ancestral Puebloan: Keet Seel (Kitsʼiil), Betatakin (Bitátʼahkin), e a Casa da Inscrição(Tsʼah Biiʼ Kin). O monumento eleva-se no planalto de Shonto, tendo uma visão geral sobre o sistema montanhoso de Tsegi, a oeste de Kayenta, Arizona. Oferece um centro aos visitantes com um museu, dois trajetos curtos às mesetas, dois parques de campismo e uma área de piqueniques. Alguns guardas guiam os visitantes em viagens gratuitas aos relevos de Keet Seel e Betatakin. O local da Casa da Inscrição, mais a oeste, está neste momento encerrado ao público.", "new": "O Monumento Nacional Navajo situa-se no norte do Arizona, no território da Nação Navajo. Preserva três conjuntos de habitações construídas em abrigos nas falésias pelos povos ancestrais pueblo: Keet Seel (Kitsʼiil), Betatakin (Bitátʼahkin) e Inscription House (Tsʼah Biiʼ Kin). Fica no planalto de Shonto, com vista para o sistema de desfiladeiros de Tsegi, a oeste de Kayenta. Tem um centro de visitantes com museu, trilhos, parques de campismo e uma área de piqueniques.", "x": 0.34875, "y": 0.49875}]
 property var pages: []
 function all(root){var result=[root];if(root.children)for(var child of root.children)result=result.concat(all(child));return result;}
 function click(item){var p=item.mapToItem(pageView,item.width/2,item.height/2);verify(p.x>=0&&p.y>=0&&p.x<pageView.width&&p.y<pageView.height,'Painted control inside viewport');mouseClick(item,item.width/2,item.height/2,Qt.LeftButton,Qt.NoModifier,10);wait(50);}
 function icon(suffix){var image=all(bar).find(child=>child.source!==undefined&&String(child.source).endsWith(suffix)&&child.visible);verify(image!==undefined,suffix);click(image);wait(400);}
 function spots(){return all(activityBackground).filter(node=>node.source!==undefined && /\/(question|key|suitcase|cat|chicken|cow|dog|duck|horse|owl|pig|sheep)\.svg$/.test(String(node.source))&&node.visible&&node.width>0&&node.height>0);}
 function continueSound(){if(audioNeededDialog.active){var button=all(audioNeededDialog.item).find(node=>node.text!==undefined&&String(node.text)===String(audioNeededDialog.item.button2Text)&&node.clicked!==undefined);verify(button!==undefined);click(button);wait(300);}}

 function test_correct_six_visible_presentations(){
  wait(1200);continueSound();
  for(var map=1;map<=5;map++){
   compare(bar.level,map);compare(score.currentSubLevel,1);
   for(var lesson of targets.filter(row=>row.map===map)){
    var card=spots().find(node=>{var point=node.mapToItem(pageView,node.width/2,node.height/2);return Math.abs(point.x/pageView.width-lesson.x)<0.005&&Math.abs(point.y/pageView.height-lesson.y)<0.005;});verify(card!==undefined);click(card);tryCompare(descriptionPanel,'visible',true,2000);wait(1300);
    var image=all(descriptionPanel).find(node=>node.source!==undefined&&String(node.source).endsWith('.webp'));verify(image!==undefined);tryCompare(image,'status',Image.Ready,2000);compare(String(image.source),lesson.image);
    pages.push({image:String(image.source),title:String(descriptionPanel.title),description:String(descriptionPanel.description),map:map});grabImage(pageView).save('/home/proteu/Projetos/GCompris-qt-worktrees/pt-world-exploration/.scratch/pt-pt/functional-exploration/supplement-red/supplement-m'+map+'-'+(pages.length-1)+'.png');
    keyClick(Qt.Key_Escape);tryCompare(descriptionPanel,'visible',false,2000);
   }
   if(map<5){var attempts=0;while(bar.level===map&&attempts++<3)icon('bar_next.svg');compare(bar.level,map+1);wait(500);}
  }
  compare(pages.length,6);verify(pages.every(page=>page.description===targets.find(row=>row.image===page.image).new),'Geography, geology and dwellings preserve the source meaning in PT-PT');
 }
 function cleanupTestCase(){console.log('NATIVE_RESULT',JSON.stringify({failures:qtest_results.failCount,passes:qtest_results.passCount,pages:pages}));}
}

    }
}
